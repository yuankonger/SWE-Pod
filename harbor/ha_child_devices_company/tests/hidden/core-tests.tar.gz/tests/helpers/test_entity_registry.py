"""Tests for the Entity Registry."""

import asyncio
from datetime import datetime, timedelta
from functools import partial
from typing import Any
from unittest.mock import patch

import attr
from freezegun.api import FrozenDateTimeFactory
import pytest
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import (
    EVENT_HOMEASSISTANT_START,
    STATE_UNAVAILABLE,
    EntityCategory,
)
from homeassistant.core import CoreState, Event, HomeAssistant, callback
from homeassistant.exceptions import MaxLengthExceeded
from homeassistant.helpers import (
    area_registry as ar,
    device_registry as dr,
    entity_registry as er,
    floor_registry as fr,
)
from homeassistant.helpers.event import async_track_entity_registry_updated_event
from homeassistant.helpers.typing import UNDEFINED
from homeassistant.util.dt import utc_from_timestamp, utcnow

from tests.common import (
    ANY,
    MockConfigEntry,
    MockEntity,
    MockEntityPlatform,
    RegistryEntryWithDefaults,
    async_capture_events,
    async_fire_time_changed,
    flush_store,
)

YAML__OPEN_PATH = "homeassistant.util.yaml.loader.open"


@pytest.mark.parametrize(
    ("aliases", "allow_empty", "expected"),
    [
        ([er.COMPUTED_NAME], True, ["My Device My Entity"]),
        ([er.COMPUTED_NAME, "custom1"], True, ["My Device My Entity", "custom1"]),
        (["custom1", "  custom2  "], True, ["custom1", "custom2"]),
        ([], True, []),
        ([], False, ["My Device My Entity"]),
        ([er.COMPUTED_NAME], False, ["My Device My Entity"]),
    ],
)
async def test_get_all_entity_aliases(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    aliases: list[er.AliasEntry],
    allow_empty: bool,
    expected: list[str],
) -> None:
    """Test getting all names/aliases for an entity."""
    mock_config = MockConfigEntry(domain="light")
    mock_config.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=mock_config.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
        name="My Device",
    )

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        config_entry=mock_config,
        device_id=device_entry.id,
        has_entity_name=True,
        original_name="My Entity",
    )
    entry = entity_registry.async_update_entity(entry.entity_id, aliases=aliases)

    assert er.async_get_entity_aliases(hass, entry, allow_empty=allow_empty) == (
        expected
    )


@pytest.mark.parametrize(
    ("prefix", "entity_name", "expected"),
    [
        (None, "Sensor", None),
        ("My Device", None, None),
        ("My Device", "My Device temperature", "Temperature"),
        ("My Device", "My Device Temperature", "Temperature"),
        ("My Device", "My Device", ""),
        ("My Device", "My Device-temperature", "Temperature"),
        ("My Device", "My Device:temperature", "Temperature"),
        ("My Device", "My Device - Temperature", "Temperature"),
        ("My Device", "MyDevice temperature", None),
        ("My Device", "Completely Different", None),
        ("My Device", "My Dev", None),
        ("My Device", "My Dev Ice", None),
        ("Sun", "Sunrise sensor", None),
        ("Straße", "STRASSE sensor", "Sensor"),
        ("STRASSE", "straße sensor", "Sensor"),
        ("İstanbul", "i̇stanbul weather", "Weather"),
        ("İstanbul", "istanbul weather", None),
        ("As", "Aß value", None),
    ],
)
def test_strip_prefix_from_entity_name(
    prefix: str | None,
    entity_name: str | None,
    expected: str | None,
) -> None:
    """Test stripping device name prefix from entity name."""
    assert er._async_strip_prefix_from_entity_name(entity_name, prefix) == expected


async def test_get(entity_registry: er.EntityRegistry) -> None:
    """Test we can get an item."""
    entry = entity_registry.async_get_or_create("light", "hue", "1234")

    assert entity_registry.async_get(entry.entity_id) is entry
    assert entity_registry.async_get(entry.id) is entry
    assert entity_registry.async_get("blah") is None
    assert entity_registry.async_get("blah.blah") is None


async def test_get_or_create_returns_same_entry(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Make sure we do not duplicate entries."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    entry = entity_registry.async_get_or_create("light", "hue", "1234")
    entry2 = entity_registry.async_get_or_create("light", "hue", "1234")

    await hass.async_block_till_done()

    assert len(entity_registry.entities) == 1
    assert entry is entry2
    assert entry.entity_id == "light.hue_1234"
    assert len(update_events) == 1
    assert update_events[0].data == {
        "action": "create",
        "entity_id": entry.entity_id,
    }


def test_get_or_create_suggested_object_id(entity_registry: er.EntityRegistry) -> None:
    """Test that suggested_object_id works."""
    entry = entity_registry.async_get_or_create(
        "light", "hue", "1234", suggested_object_id="beer"
    )

    assert entry.entity_id == "light.beer"


def test_get_or_create_updates_data(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    freezer: FrozenDateTimeFactory,
) -> None:
    """Test that we update data in get_or_create."""
    config_subentry_id = "blabla"
    orig_config_entry = MockConfigEntry(
        domain="light",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id=config_subentry_id,
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            )
        ],
    )
    orig_config_entry.add_to_hass(hass)
    orig_device_entry = device_registry.async_get_or_create(
        config_entry_id=orig_config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    created = datetime.fromisoformat("2024-02-14T12:00:00.0+00:00")
    freezer.move_to(created)

    orig_entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        capabilities={"max": 100},
        config_entry=orig_config_entry,
        config_subentry_id=config_subentry_id,
        device_id=orig_device_entry.id,
        disabled_by=er.RegistryEntryDisabler.HASS,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        original_device_class="mock-device-class",
        original_icon="initial-original_icon",
        original_name="initial-original_name",
        supported_features=5,
        translation_key="initial-translation_key",
        unit_of_measurement="initial-unit_of_measurement",
    )

    assert set(entity_registry.async_device_ids()) == {orig_device_entry.id}

    assert orig_entry == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="5678",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        capabilities={"max": 100},
        config_entry_id=orig_config_entry.entry_id,
        config_subentry_id=config_subentry_id,
        created_at=created,
        device_class=None,
        device_id=orig_device_entry.id,
        disabled_by=er.RegistryEntryDisabler.HASS,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        icon=None,
        id=orig_entry.id,
        modified_at=created,
        name=None,
        object_id_base=None,
        options=None,
        original_device_class="mock-device-class",
        original_icon="initial-original_icon",
        original_name="initial-original_name",
        suggested_object_id=None,
        supported_features=5,
        translation_key="initial-translation_key",
        unit_of_measurement="initial-unit_of_measurement",
    )

    new_config_entry = MockConfigEntry(domain="light")
    new_config_entry.add_to_hass(hass)
    new_device_entry = device_registry.async_get_or_create(
        config_entry_id=new_config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "34:56:AB:CD:EF:12")},
    )
    modified = created + timedelta(minutes=5)
    freezer.move_to(modified)

    new_entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        capabilities={"new-max": 150},
        config_entry=new_config_entry,
        config_subentry_id=None,
        device_id=new_device_entry.id,
        disabled_by=er.RegistryEntryDisabler.USER,
        entity_category=EntityCategory.DIAGNOSTIC,
        has_entity_name=False,
        hidden_by=er.RegistryEntryHider.USER,
        object_id_base="updated-name",
        original_device_class="new-mock-device-class",
        original_icon="updated-original_icon",
        original_name="updated-original_name",
        suggested_object_id="suggested",
        supported_features=10,
        translation_key="updated-translation_key",
        unit_of_measurement="updated-unit_of_measurement",
    )

    assert new_entry == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="5678",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        capabilities={"new-max": 150},
        config_entry_id=new_config_entry.entry_id,
        config_subentry_id=None,
        created_at=created,
        device_class=None,
        device_id=new_device_entry.id,
        disabled_by=er.RegistryEntryDisabler.HASS,  # Should not be updated
        entity_category=EntityCategory.DIAGNOSTIC,
        has_entity_name=False,
        hidden_by=er.RegistryEntryHider.INTEGRATION,  # Should not be updated
        icon=None,
        id=orig_entry.id,
        modified_at=modified,
        name=None,
        object_id_base="updated-name",
        options=None,
        original_device_class="new-mock-device-class",
        original_icon="updated-original_icon",
        original_name="updated-original_name",
        suggested_object_id="suggested",
        supported_features=10,
        translation_key="updated-translation_key",
        unit_of_measurement="updated-unit_of_measurement",
    )

    assert set(entity_registry.async_device_ids()) == {new_device_entry.id}
    modified = created + timedelta(minutes=5)
    freezer.move_to(modified)

    new_entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        capabilities=None,
        config_entry=None,
        device_id=None,
        disabled_by=None,
        entity_category=None,
        has_entity_name=None,
        hidden_by=None,
        object_id_base=None,
        original_device_class=None,
        original_icon=None,
        original_name=None,
        suggested_object_id=None,
        supported_features=None,
        translation_key=None,
        unit_of_measurement=None,
    )

    assert new_entry == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="5678",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        capabilities=None,
        config_entry_id=None,
        config_subentry_id=None,
        created_at=created,
        device_class=None,
        device_id=None,
        disabled_by=er.RegistryEntryDisabler.HASS,  # Should not be updated
        entity_category=None,
        has_entity_name=None,
        hidden_by=er.RegistryEntryHider.INTEGRATION,  # Should not be updated
        icon=None,
        id=orig_entry.id,
        modified_at=modified,
        name=None,
        object_id_base=None,
        options=None,
        original_device_class=None,
        original_icon=None,
        original_name=None,
        suggested_object_id=None,
        supported_features=0,  # supported_features is stored as an int
        translation_key=None,
        unit_of_measurement=None,
    )

    assert set(entity_registry.async_device_ids()) == set()


def test_get_or_create_suggested_object_id_conflict_register(
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that we don't generate an entity id that is already registered."""
    entry = entity_registry.async_get_or_create(
        "light", "hue", "1234", suggested_object_id="beer"
    )
    entry2 = entity_registry.async_get_or_create(
        "light", "hue", "5678", suggested_object_id="beer"
    )

    assert entry.entity_id == "light.beer"
    assert entry2.entity_id == "light.beer_2"


def test_get_or_create_suggested_object_id_conflict_existing(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test that we don't generate an entity id that currently exists."""
    hass.states.async_set("light.hue_1234", "on")
    entry = entity_registry.async_get_or_create("light", "hue", "1234")
    assert entry.entity_id == "light.hue_1234_2"


def test_remove(entity_registry: er.EntityRegistry) -> None:
    """Test that we can remove an item."""
    entry = entity_registry.async_get_or_create("light", "hue", "1234")

    assert not entity_registry.deleted_entities
    assert list(entity_registry.entities) == [entry.entity_id]

    # Remove the item
    entity_registry.async_remove(entry.entity_id)
    assert list(entity_registry.deleted_entities) == [("light", "hue", "1234")]
    assert not entity_registry.entities

    # Remove the item again
    entity_registry.async_remove(entry.entity_id)
    assert list(entity_registry.deleted_entities) == [("light", "hue", "1234")]
    assert not entity_registry.entities


def test_create_triggers_save(entity_registry: er.EntityRegistry) -> None:
    """Test that registering entry triggers a save."""
    with patch.object(entity_registry, "async_schedule_save") as mock_schedule_save:
        entity_registry.async_get_or_create("light", "hue", "1234")

    assert len(mock_schedule_save.mock_calls) == 1


async def test_loading_saving_data(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that we load/save data correctly."""
    mock_config = MockConfigEntry(domain="light")
    mock_config.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=mock_config.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )

    orig_entry1 = entity_registry.async_get_or_create("light", "hue", "1234")
    orig_entry2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        capabilities={"max": 100},
        config_entry=mock_config,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.HASS,
        entity_category=EntityCategory.CONFIG,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        has_entity_name=True,
        original_device_class="mock-device-class",
        original_icon="hass:original-icon",
        original_name="Original Name",
        supported_features=5,
        translation_key="initial-translation_key",
        unit_of_measurement="initial-unit_of_measurement",
    )
    entity_registry.async_update_entity(
        orig_entry2.entity_id,
        aliases=["initial_alias_1", "initial_alias_2"],
        area_id="mock-area-id",
        device_class="user-class",
        name="User Name",
        icon="hass:user-icon",
    )
    entity_registry.async_update_entity_options(
        orig_entry2.entity_id, "light", {"minimum_brightness": 20}
    )
    entity_registry.async_update_entity(
        orig_entry2.entity_id,
        categories={"scope", "id"},
        labels={"label1", "label2"},
    )
    orig_entry2 = entity_registry.async_get(orig_entry2.entity_id)
    orig_entry3 = entity_registry.async_get_or_create("light", "hue", "ABCD")
    orig_entry4 = entity_registry.async_get_or_create("light", "hue", "EFGH")
    entity_registry.async_remove(orig_entry3.entity_id)
    entity_registry.async_remove(orig_entry4.entity_id)

    assert len(entity_registry.entities) == 2
    assert len(entity_registry.deleted_entities) == 2

    entity_registry.async_update_settings(
        entity_id_parts=[er.EntityNamePart.ENTITY, er.EntityNamePart.DEVICE]
    )

    # Now load written data in new registry
    registry2 = er.EntityRegistry(hass)
    await flush_store(entity_registry._store)
    await registry2.async_load()

    # Ensure same order
    assert list(entity_registry.entities) == list(registry2.entities)
    assert list(entity_registry.deleted_entities) == list(registry2.deleted_entities)
    assert registry2.settings == entity_registry.settings
    assert registry2.settings.entity_id_parts == (
        er.EntityNamePart.ENTITY,
        er.EntityNamePart.DEVICE,
    )
    new_entry1 = entity_registry.async_get_or_create("light", "hue", "1234")
    new_entry2 = entity_registry.async_get_or_create("light", "hue", "5678")
    new_entry3 = entity_registry.async_get_or_create("light", "hue", "ABCD")
    new_entry4 = entity_registry.async_get_or_create("light", "hue", "EFGH")

    assert orig_entry1 == new_entry1
    assert orig_entry2 == new_entry2

    # By converting a deleted device to a active device, the modified_at will be updated
    assert orig_entry3.modified_at < new_entry3.modified_at
    assert attr.evolve(orig_entry3, modified_at=new_entry3.modified_at) == new_entry3
    assert orig_entry4.modified_at < new_entry4.modified_at
    assert attr.evolve(orig_entry4, modified_at=new_entry4.modified_at) == new_entry4

    assert new_entry2.area_id == "mock-area-id"
    assert new_entry2.categories == {"scope", "id"}
    assert new_entry2.capabilities == {"max": 100}
    assert new_entry2.config_entry_id == mock_config.entry_id
    assert new_entry2.device_class == "user-class"
    assert new_entry2.device_id == device_entry.id
    assert new_entry2.disabled_by is er.RegistryEntryDisabler.HASS
    assert new_entry2.entity_category == "config"
    assert new_entry2.icon == "hass:user-icon"
    assert new_entry2.hidden_by == er.RegistryEntryHider.INTEGRATION
    assert new_entry2.has_entity_name is True
    assert new_entry2.labels == {"label1", "label2"}
    assert new_entry2.name == "User Name"
    assert new_entry2.options == {"light": {"minimum_brightness": 20}}
    assert new_entry2.original_device_class == "mock-device-class"
    assert new_entry2.original_icon == "hass:original-icon"
    assert new_entry2.original_name == "Original Name"
    assert new_entry2.supported_features == 5
    assert new_entry2.translation_key == "initial-translation_key"
    assert new_entry2.unit_of_measurement == "initial-unit_of_measurement"


@pytest.mark.parametrize("load_registries", [False])
async def test_entity_registry_loading_waits_for_device_registry(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """Test entity registry waits for device registry when loaded concurrently.

    Both registries are loaded in parallel during bootstrap via asyncio.gather.
    The entity registry accesses device registry during loading. This test delays
    the device registry store load so entity registry attempts to load first.
    """
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    "entity_id": "test.my_entity",
                    "device_id": "some-device",
                    "platform": "test_platform",
                    "unique_id": "unique-1",
                },
            ]
        },
    }

    original_load = dr.DeviceRegistryStore.async_load

    async def delayed_load(self: dr.DeviceRegistryStore) -> Any:
        await asyncio.sleep(0)
        return await original_load(self)

    dr.async_setup(hass)

    with patch.object(dr.DeviceRegistryStore, "async_load", delayed_load):
        await asyncio.gather(
            er.async_load(hass),
            dr.async_load(hass),
        )

    registry = er.async_get(hass)
    assert registry.async_get("test.my_entity") is not None


@pytest.mark.parametrize("load_registries", [False])
async def test_entity_load_detaches_from_dropped_device(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """An entity referencing a device that no longer exists is detached on load.

    The device migration drops a device with no config entry; an entity that pointed at
    it must be detached rather than left on a removed device id.
    """
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    "entity_id": "test.my_entity",
                    "device_id": "gone-device",
                    "platform": "test_platform",
                    "unique_id": "unique-1",
                },
            ]
        },
    }

    dr.async_setup(hass)
    await asyncio.gather(er.async_load(hass), dr.async_load(hass))

    registry = er.async_get(hass)
    entity = registry.async_get("test.my_entity")
    assert entity is not None
    assert entity.device_id is None


@pytest.mark.parametrize("load_registries", [False])
async def test_entity_load_keeps_child_device(
    hass: HomeAssistant,
    hass_storage: dict[str, Any],
) -> None:
    """An entity on a child device keeps its device id on load.

    The composite-split migration remaps entity device ids on load; a child device is
    not a composite and is in its own container, so an entity on it must keep its device
    id rather than be detached.
    """
    mock_config_entry = MockConfigEntry()
    mock_config_entry.add_to_hass(hass)
    hass_storage[dr.STORAGE_KEY] = {
        "version": dr.STORAGE_VERSION_MAJOR,
        "minor_version": dr.STORAGE_VERSION_MINOR,
        "key": dr.STORAGE_KEY,
        "data": {
            "devices": [
                {
                    "area_id": None,
                    "config_entry_id": mock_config_entry.entry_id,
                    "config_subentry_id": None,
                    "composite_device_id": None,
                    "composite_primary_config_entry": None,
                    "split_at": None,
                    "has_composite_identifiers": False,
                    "configuration_url": None,
                    "connections": [],
                    "created_at": "2024-01-01T00:00:00+00:00",
                    "disabled_by": None,
                    "entry_type": None,
                    "hw_version": None,
                    "id": "parentdeviceid",
                    "identifiers": [["test", "strip"]],
                    "labels": [],
                    "manufacturer": None,
                    "model": None,
                    "model_id": None,
                    "modified_at": "2024-01-01T00:00:00+00:00",
                    "name_by_user": None,
                    "name": "Power strip",
                    "primary_config_entry": mock_config_entry.entry_id,
                    "serial_number": None,
                    "sw_version": None,
                    "via_device_id": None,
                }
            ],
            "child_devices": [
                {
                    "area_id": None,
                    "config_entry_id": mock_config_entry.entry_id,
                    "config_subentry_id": None,
                    "created_at": "2024-01-01T00:00:00+00:00",
                    "disabled_by": None,
                    "id": "childdeviceid",
                    "identifiers": [["test", "strip_outlet_1"]],
                    "labels": [],
                    "modified_at": "2024-01-01T00:00:00+00:00",
                    "name_by_user": None,
                    "name": "Outlet 1",
                    "parent_device_id": "parentdeviceid",
                }
            ],
            "deleted_devices": [],
        },
    }
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    "entity_id": "test.child_entity",
                    "device_id": "childdeviceid",
                    "platform": "test_platform",
                    "unique_id": "unique-1",
                },
            ]
        },
    }

    dr.async_setup(hass)
    await asyncio.gather(er.async_load(hass), dr.async_load(hass))

    registry = er.async_get(hass)
    entity = registry.async_get("test.child_entity")
    assert entity is not None
    assert entity.device_id == "childdeviceid"


def test_get_available_entity_id_considers_registered_entities(
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that we don't create entity id that are already registered."""
    entry = entity_registry.async_get_or_create("light", "hue", "1234")
    assert entry.entity_id == "light.hue_1234"
    assert (
        entity_registry.async_get_available_entity_id("light", "hue_1234")
        == "light.hue_1234_2"
    )


def test_get_available_entity_id_considers_existing_entities(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test that we don't create entity id that currently exists."""
    hass.states.async_set("light.kitchen", "on")
    assert (
        entity_registry.async_get_available_entity_id("light", "kitchen")
        == "light.kitchen_2"
    )


@pytest.mark.parametrize(
    (
        "device_name",
        "device_area_name",
        "entity_area_name",
        "object_id_base",
        "suggested_object_id",
        "user_name",
        "expected_initial_entity_id",
        "expected_entity_id",
    ),
    [
        pytest.param(
            None,
            None,
            None,
            "My Sensor",
            None,
            None,
            "sensor.my_sensor",
            "sensor.my_sensor",
            id="no_device_no_area",
        ),
        pytest.param(
            "Lamp",
            None,
            None,
            "Temperature",
            None,
            None,
            "sensor.lamp_temperature",
            "sensor.lamp_temperature",
            id="device_no_area",
        ),
        pytest.param(
            "Lamp",
            None,
            None,
            "Temperature",
            "custom_id",
            None,
            "sensor.custom_id",
            "sensor.custom_id",
            id="suggested_object_id",
        ),
        pytest.param(
            "Lamp",
            None,
            None,
            "Temperature",
            "custom_id",
            "Humidity",
            "sensor.custom_id",
            "sensor.lamp_humidity",
            id="user_name",
        ),
        pytest.param(
            "Lamp",
            None,
            None,
            "Temperature",
            None,
            "Lamp Sensor",
            "sensor.lamp_temperature",
            "sensor.lamp_sensor",
            id="user_name_unprefixed",
        ),
        pytest.param(
            "Lamp",
            "Kitchen",
            None,
            "Temperature",
            None,
            None,
            "sensor.kitchen_lamp_temperature",
            "sensor.kitchen_lamp_temperature",
            id="device_area",
        ),
        pytest.param(
            "Lamp",
            "Kitchen",
            "Garage",
            "Temperature",
            None,
            None,
            "sensor.kitchen_lamp_temperature",
            "sensor.garage_lamp_temperature",
            id="entity_area",
        ),
        pytest.param(
            None,
            None,
            "Kitchen",
            "My Sensor",
            None,
            None,
            "sensor.my_sensor",
            "sensor.kitchen_my_sensor",
            id="entity_area_no_device",
        ),
        pytest.param(
            "Lamp",
            "Kitchen",
            "Garage",
            "Temperature",
            "custom_id",
            None,
            "sensor.custom_id",
            "sensor.custom_id",
            id="suggested_object_id_area",
        ),
    ],
)
def test_generate_entity_id(
    hass: HomeAssistant,
    area_registry: ar.AreaRegistry,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    device_name: str | None,
    device_area_name: str | None,
    entity_area_name: str | None,
    object_id_base: str | None,
    suggested_object_id: str | None,
    user_name: str | None,
    expected_initial_entity_id: str,
    expected_entity_id: str,
) -> None:
    """Test generating and regenerating entity IDs."""
    config_entry = MockConfigEntry(domain="sensor")
    config_entry.add_to_hass(hass)

    device_id: str | None = None
    if device_name is not None:
        device_entry = device_registry.async_get_or_create(
            config_entry_id=config_entry.entry_id,
            connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
            name=device_name,
        )
        device_id = device_entry.id
        if device_area_name is not None:
            device_area = area_registry.async_create(device_area_name)
            device_registry.async_update_device(device_id, area_id=device_area.id)

    entry = entity_registry.async_get_or_create(
        "sensor",
        "test",
        "1234",
        config_entry=config_entry,
        device_id=device_id,
        has_entity_name=True,
        object_id_base=object_id_base,
        original_name=object_id_base,
        suggested_object_id=suggested_object_id,
    )
    assert entry.entity_id == expected_initial_entity_id

    if entity_area_name is not None:
        entity_area = area_registry.async_create(entity_area_name)
        entry = entity_registry.async_update_entity(
            entry.entity_id, area_id=entity_area.id
        )

    if user_name is not None:
        entry = entity_registry.async_update_entity(entry.entity_id, name=user_name)

    new_entity_id = entity_registry.async_regenerate_entity_id(entry)
    assert new_entity_id == expected_entity_id


@pytest.mark.parametrize(
    (
        "entity_id_parts",
        "device_name",
        "device_area_name",
        "floor_name",
        "has_entity_name",
        "object_id_base",
        "suggested_object_id",
        "user_name",
        "expected_initial_entity_id",
        "expected_entity_id",
    ),
    [
        pytest.param(
            [
                er.EntityNamePart.FLOOR,
                er.EntityNamePart.AREA,
                er.EntityNamePart.DEVICE,
                er.EntityNamePart.ENTITY,
            ],
            "Lamp",
            "Kitchen",
            "First Floor",
            True,
            "Temperature",
            None,
            None,
            "sensor.first_floor_kitchen_lamp_temperature",
            "sensor.first_floor_kitchen_lamp_temperature",
            id="all_parts",
        ),
        pytest.param(
            [
                er.EntityNamePart.FLOOR,
                er.EntityNamePart.AREA,
                er.EntityNamePart.DEVICE,
                er.EntityNamePart.ENTITY,
            ],
            "Lamp",
            "Kitchen",
            None,
            True,
            "Temperature",
            None,
            None,
            "sensor.kitchen_lamp_temperature",
            "sensor.kitchen_lamp_temperature",
            id="area_without_floor",
        ),
        pytest.param(
            [er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY],
            "Lamp",
            "Kitchen",
            "First Floor",
            True,
            "Temperature",
            None,
            None,
            "sensor.lamp_temperature",
            "sensor.lamp_temperature",
            id="area_not_included",
        ),
        pytest.param(
            [
                er.EntityNamePart.FLOOR,
                er.EntityNamePart.DEVICE,
                er.EntityNamePart.ENTITY,
            ],
            "Lamp",
            "Kitchen",
            "First Floor",
            True,
            "Temperature",
            None,
            None,
            "sensor.first_floor_lamp_temperature",
            "sensor.first_floor_lamp_temperature",
            id="floor_without_area",
        ),
        pytest.param(
            [er.EntityNamePart.ENTITY, er.EntityNamePart.DEVICE],
            "Lamp",
            "Kitchen",
            None,
            True,
            "Temperature",
            None,
            None,
            "sensor.temperature_lamp",
            "sensor.temperature_lamp",
            id="reordered",
        ),
        pytest.param(
            [er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY],
            "Lamp",
            None,
            None,
            False,
            "Lamp Temperature",
            None,
            None,
            "sensor.lamp_temperature",
            "sensor.lamp_temperature",
            id="legacy_name_stripped",
        ),
        pytest.param(
            [er.EntityNamePart.ENTITY, er.EntityNamePart.DEVICE],
            "Lamp",
            None,
            None,
            False,
            "Lamp Temperature",
            None,
            None,
            "sensor.temperature_lamp",
            "sensor.temperature_lamp",
            id="legacy_name_reordered",
        ),
        pytest.param(
            [er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY],
            None,
            None,
            None,
            True,
            "My Sensor",
            None,
            None,
            "sensor.my_sensor",
            "sensor.my_sensor",
            id="no_device",
        ),
        pytest.param(
            [er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY],
            "Lamp",
            None,
            None,
            True,
            "Temperature",
            "custom_id",
            None,
            "sensor.custom_id",
            "sensor.custom_id",
            id="suggested_object_id_respected",
        ),
        pytest.param(
            [er.EntityNamePart.ENTITY, er.EntityNamePart.DEVICE],
            "Lamp",
            None,
            None,
            True,
            "Temperature",
            None,
            "Lamp Humidity",
            "sensor.temperature_lamp",
            "sensor.humidity_lamp",
            id="user_name_unprefixed",
        ),
        pytest.param(
            [er.EntityNamePart.ENTITY, er.EntityNamePart.DEVICE],
            "Lamp",
            None,
            None,
            True,
            "Temperature",
            "custom_id",
            "Lamp Humidity",
            "sensor.custom_id",
            "sensor.humidity_lamp",
            id="user_name_over_suggested_object_id",
        ),
        pytest.param(
            [er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY],
            None,
            None,
            None,
            True,
            None,
            None,
            None,
            "sensor.test_1234",
            "sensor.test_1234",
            id="all_parts_empty",
        ),
    ],
)
def test_generate_entity_id_parts(
    hass: HomeAssistant,
    area_registry: ar.AreaRegistry,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    floor_registry: fr.FloorRegistry,
    entity_id_parts: list[er.EntityNamePart],
    device_name: str | None,
    device_area_name: str | None,
    floor_name: str | None,
    has_entity_name: bool,
    object_id_base: str | None,
    suggested_object_id: str | None,
    user_name: str | None,
    expected_initial_entity_id: str,
    expected_entity_id: str,
) -> None:
    """Test generating and regenerating entity IDs with configured parts."""
    config_entry = MockConfigEntry(domain="sensor")
    config_entry.add_to_hass(hass)

    entity_registry.async_update_settings(entity_id_parts=entity_id_parts)

    device_id: str | None = None
    if device_name is not None:
        device_entry = device_registry.async_get_or_create(
            config_entry_id=config_entry.entry_id,
            connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
            name=device_name,
        )
        device_id = device_entry.id
        if device_area_name is not None:
            device_area = area_registry.async_create(device_area_name)
            if floor_name is not None:
                floor = floor_registry.async_create(floor_name)
                area_registry.async_update(device_area.id, floor_id=floor.floor_id)
            device_registry.async_update_device(device_id, area_id=device_area.id)

    entry = entity_registry.async_get_or_create(
        "sensor",
        "test",
        "1234",
        config_entry=config_entry,
        device_id=device_id,
        has_entity_name=has_entity_name,
        object_id_base=object_id_base,
        original_name=object_id_base,
        suggested_object_id=suggested_object_id,
    )
    assert entry.entity_id == expected_initial_entity_id

    if user_name is not None:
        entry = entity_registry.async_update_entity(entry.entity_id, name=user_name)

    new_entity_id = entity_registry.async_regenerate_entity_id(entry)
    assert new_entity_id == expected_entity_id


def test_generate_entity_id_parts_entity_area(
    hass: HomeAssistant,
    area_registry: ar.AreaRegistry,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    floor_registry: fr.FloorRegistry,
) -> None:
    """Test the entity area override drives the floor part."""
    config_entry = MockConfigEntry(domain="sensor")
    config_entry.add_to_hass(hass)

    entity_registry.async_update_settings(
        entity_id_parts=[
            er.EntityNamePart.FLOOR,
            er.EntityNamePart.AREA,
            er.EntityNamePart.DEVICE,
            er.EntityNamePart.ENTITY,
        ]
    )

    first_floor = floor_registry.async_create("First Floor")
    second_floor = floor_registry.async_create("Second Floor")
    kitchen = area_registry.async_create("Kitchen")
    area_registry.async_update(kitchen.id, floor_id=first_floor.floor_id)
    garage = area_registry.async_create("Garage")
    area_registry.async_update(garage.id, floor_id=second_floor.floor_id)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
        name="Lamp",
    )
    device_registry.async_update_device(device_entry.id, area_id=kitchen.id)

    entry = entity_registry.async_get_or_create(
        "sensor",
        "test",
        "1234",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=True,
        object_id_base="Temperature",
        original_name="Temperature",
    )
    assert entry.entity_id == "sensor.first_floor_kitchen_lamp_temperature"

    entry = entity_registry.async_update_entity(entry.entity_id, area_id=garage.id)

    new_entity_id = entity_registry.async_regenerate_entity_id(entry)
    assert new_entity_id == "sensor.second_floor_garage_lamp_temperature"


def test_regenerate_entity_id_after_settings_change(
    hass: HomeAssistant,
    area_registry: ar.AreaRegistry,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test regenerating an entity ID after the parts setting changed."""
    config_entry = MockConfigEntry(domain="sensor")
    config_entry.add_to_hass(hass)

    kitchen = area_registry.async_create("Kitchen")
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
        name="Lamp",
    )
    device_registry.async_update_device(device_entry.id, area_id=kitchen.id)

    entry = entity_registry.async_get_or_create(
        "sensor",
        "test",
        "1234",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=True,
        object_id_base="Temperature",
        original_name="Temperature",
    )
    assert entry.entity_id == "sensor.kitchen_lamp_temperature"

    entity_registry.async_update_settings(
        entity_id_parts=[er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY]
    )

    new_entity_id = entity_registry.async_regenerate_entity_id(entry)
    assert new_entity_id == "sensor.lamp_temperature"


def test_entity_id_parts_do_not_affect_full_entity_name(
    hass: HomeAssistant,
    area_registry: ar.AreaRegistry,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    floor_registry: fr.FloorRegistry,
) -> None:
    """Test the entity ID parts setting does not affect the full entity name."""
    config_entry = MockConfigEntry(domain="sensor")
    config_entry.add_to_hass(hass)

    entity_registry.async_update_settings(
        entity_id_parts=[
            er.EntityNamePart.FLOOR,
            er.EntityNamePart.AREA,
            er.EntityNamePart.ENTITY,
            er.EntityNamePart.DEVICE,
        ]
    )

    floor = floor_registry.async_create("First Floor")
    kitchen = area_registry.async_create("Kitchen")
    area_registry.async_update(kitchen.id, floor_id=floor.floor_id)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
        name="Lamp",
    )
    device_registry.async_update_device(device_entry.id, area_id=kitchen.id)

    entry = entity_registry.async_get_or_create(
        "sensor",
        "test",
        "1234",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=True,
        object_id_base="Temperature",
        original_name="Temperature",
    )
    assert entry.entity_id == "sensor.first_floor_kitchen_temperature_lamp"

    assert er.async_get_full_entity_name(hass, entry) == "Lamp Temperature"


def test_update_settings(entity_registry: er.EntityRegistry) -> None:
    """Test updating entity registry settings."""
    assert entity_registry.settings == er.EntityRegistrySettings(entity_id_parts=None)

    with patch.object(entity_registry, "async_schedule_save") as mock_schedule_save:
        settings = entity_registry.async_update_settings(
            entity_id_parts=[er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY]
        )
    assert settings.entity_id_parts == (
        er.EntityNamePart.DEVICE,
        er.EntityNamePart.ENTITY,
    )
    assert entity_registry.settings == settings
    assert len(mock_schedule_save.mock_calls) == 1

    # Unchanged settings don't trigger a save
    with patch.object(entity_registry, "async_schedule_save") as mock_schedule_save:
        settings = entity_registry.async_update_settings(
            entity_id_parts=[er.EntityNamePart.DEVICE, er.EntityNamePart.ENTITY]
        )
        entity_registry.async_update_settings()
    assert settings.entity_id_parts == (
        er.EntityNamePart.DEVICE,
        er.EntityNamePart.ENTITY,
    )
    assert len(mock_schedule_save.mock_calls) == 0

    with patch.object(entity_registry, "async_schedule_save") as mock_schedule_save:
        settings = entity_registry.async_update_settings(entity_id_parts=None)
    assert settings.entity_id_parts is None
    assert entity_registry.settings == settings
    assert len(mock_schedule_save.mock_calls) == 1


def test_is_registered(entity_registry: er.EntityRegistry) -> None:
    """Test that is_registered works."""
    entry = entity_registry.async_get_or_create("light", "hue", "1234")
    assert entity_registry.async_is_registered(entry.entity_id)
    assert not entity_registry.async_is_registered("light.non_existing")


@pytest.mark.parametrize("load_registries", [False])
async def test_filter_on_load(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """Test we transform some data when loading from storage."""
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    "entity_id": "test.named",
                    "platform": "super_platform",
                    "unique_id": "with-name",
                    "name": "registry override",
                },
                # This entity's name should be None
                {
                    "entity_id": "test.no_name",
                    "platform": "super_platform",
                    "unique_id": "without-name",
                },
                {
                    "entity_id": "test.disabled_user",
                    "platform": "super_platform",
                    "unique_id": "disabled-user",
                    "disabled_by": "user",  # We store the string representation
                },
                {
                    "entity_id": "test.disabled_hass",
                    "platform": "super_platform",
                    "unique_id": "disabled-hass",
                    "disabled_by": "hass",  # We store the string representation
                },
            ]
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)

    await er.async_load(hass)
    registry = er.async_get(hass)

    assert len(registry.entities) == 4
    assert set(registry.entities.keys()) == {
        "test.disabled_hass",
        "test.disabled_user",
        "test.named",
        "test.no_name",
    }

    entry_with_name = registry.async_get_or_create(
        "test", "super_platform", "with-name"
    )
    entry_without_name = registry.async_get_or_create(
        "test", "super_platform", "without-name"
    )
    assert entry_with_name.name == "registry override"
    assert entry_without_name.name is None
    assert not entry_with_name.disabled
    assert entry_with_name.created_at == utc_from_timestamp(0)
    assert entry_with_name.modified_at == utc_from_timestamp(0)

    entry_disabled_hass = registry.async_get_or_create(
        "test", "super_platform", "disabled-hass"
    )
    entry_disabled_user = registry.async_get_or_create(
        "test", "super_platform", "disabled-user"
    )
    assert entry_disabled_hass.disabled
    assert entry_disabled_hass.disabled_by is er.RegistryEntryDisabler.HASS
    assert entry_disabled_user.disabled
    assert entry_disabled_user.disabled_by is er.RegistryEntryDisabler.USER


@pytest.mark.parametrize("load_registries", [False])
async def test_load_bad_data(
    hass: HomeAssistant,
    hass_storage: dict[str, Any],
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Test loading invalid data."""
    hass_storage[er.STORAGE_KEY] = {
        "version": er.STORAGE_VERSION_MAJOR,
        "minor_version": er.STORAGE_VERSION_MINOR,
        "data": {
            "entities": [
                {
                    "aliases": [],
                    "aliases_v2": [],
                    "area_id": None,
                    "capabilities": None,
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "2024-02-14T12:00:00.900075+00:00",
                    "device_class": None,
                    "device_id": None,
                    "disabled_by": None,
                    "entity_category": None,
                    "entity_id": "test.test1",
                    "has_entity_name": False,
                    "hidden_by": None,
                    "icon": None,
                    "id": "00001",
                    "labels": [],
                    "modified_at": "2024-02-14T12:00:00.900075+00:00",
                    "name": None,
                    "object_id_base": None,
                    "options": None,
                    "original_device_class": None,
                    "original_icon": None,
                    "original_name": None,
                    "platform": "super_platform",
                    "previous_unique_id": None,
                    "suggested_object_id": None,
                    "supported_features": 0,
                    "translation_key": None,
                    "unique_id": 123,  # Should trigger warning
                    "unit_of_measurement": None,
                },
                {
                    "aliases": [],
                    "aliases_v2": [],
                    "area_id": None,
                    "capabilities": None,
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "2024-02-14T12:00:00.900075+00:00",
                    "device_class": None,
                    "device_id": None,
                    "disabled_by": None,
                    "entity_category": None,
                    "entity_id": "test.test2",
                    "has_entity_name": False,
                    "hidden_by": None,
                    "icon": None,
                    "id": "00002",
                    "labels": [],
                    "modified_at": "2024-02-14T12:00:00.900075+00:00",
                    "name": None,
                    "object_id_base": None,
                    "options": None,
                    "original_device_class": None,
                    "original_icon": None,
                    "original_name": None,
                    "platform": "super_platform",
                    "previous_unique_id": None,
                    "suggested_object_id": None,
                    "supported_features": 0,
                    "translation_key": None,
                    "unique_id": ["not", "valid"],  # Should not load
                    "unit_of_measurement": None,
                },
            ],
            "deleted_entities": [
                {
                    "aliases": [],
                    "aliases_v2": [],
                    "area_id": None,
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "2024-02-14T12:00:00.900075+00:00",
                    "device_class": None,
                    "disabled_by": None,
                    "disabled_by_undefined": False,
                    "entity_id": "test.test3",
                    "hidden_by": None,
                    "hidden_by_undefined": False,
                    "icon": None,
                    "id": "00003",
                    "labels": [],
                    "modified_at": "2024-02-14T12:00:00.900075+00:00",
                    "name": None,
                    "options": None,
                    "options_undefined": False,
                    "orphaned_timestamp": None,
                    "platform": "super_platform",
                    "unique_id": 234,  # Should not load
                },
                {
                    "aliases": [],
                    "aliases_v2": [],
                    "area_id": None,
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "2024-02-14T12:00:00.900075+00:00",
                    "device_class": None,
                    "disabled_by": None,
                    "disabled_by_undefined": False,
                    "entity_id": "test.test4",
                    "hidden_by": None,
                    "hidden_by_undefined": False,
                    "icon": None,
                    "id": "00004",
                    "labels": [],
                    "modified_at": "2024-02-14T12:00:00.900075+00:00",
                    "name": None,
                    "options": None,
                    "options_undefined": False,
                    "orphaned_timestamp": None,
                    "platform": "super_platform",
                    "unique_id": ["also", "not", "valid"],  # Should not load
                },
            ],
            "settings": {"entity_id_parts": None},
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)

    await er.async_load(hass)
    registry = er.async_get(hass)

    assert len(registry.entities) == 1
    assert set(registry.entities.keys()) == {"test.test1"}

    assert len(registry.deleted_entities) == 1
    assert set(registry.deleted_entities.keys()) == {("test", "super_platform", 234)}

    assert (
        "'test' from integration super_platform has a non string unique_id '123', "
        "please create a bug report" not in caplog.text
    )
    assert (
        "'test' from integration super_platform has a non string unique_id '234', "
        "please create a bug report" not in caplog.text
    )
    assert (
        "Entity registry entry 'test.test2' from integration super_platform could not "
        "be loaded: 'unique_id must be a string, got ['not', 'valid']', please create "
        "a bug report" in caplog.text
    )


def test_async_get_entity_id(entity_registry: er.EntityRegistry) -> None:
    """Test that entity_id is returned."""
    entry = entity_registry.async_get_or_create("light", "hue", "1234")
    assert entry.entity_id == "light.hue_1234"
    assert (
        entity_registry.async_get_entity_id("light", "hue", "1234") == "light.hue_1234"
    )
    assert entity_registry.async_get_entity_id("light", "hue", "123") is None


async def test_updating_config_entry_id(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test that we update config entry id in registry."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    mock_config_1 = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config_1.add_to_hass(hass)
    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config_1
    )

    mock_config_2 = MockConfigEntry(domain="light", entry_id="mock-id-2")
    mock_config_2.add_to_hass(hass)
    entry2 = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config_2
    )
    assert entry.entity_id == entry2.entity_id
    assert entry2.config_entry_id == "mock-id-2"

    await hass.async_block_till_done()

    assert len(update_events) == 2
    assert update_events[0].data == {
        "action": "create",
        "entity_id": entry.entity_id,
    }
    assert update_events[1].data == {
        "action": "update",
        "entity_id": entry.entity_id,
        "changes": {"config_entry_id": "mock-id-1"},
    }


async def test_removing_config_entry_id(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test that we update config entry id in registry."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    mock_config = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config.add_to_hass(hass)

    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config
    )
    assert entry.config_entry_id == "mock-id-1"
    entity_registry.async_clear_config_entry("mock-id-1")

    assert not entity_registry.entities

    await hass.async_block_till_done()

    assert len(update_events) == 2
    assert update_events[0].data == {
        "action": "create",
        "entity_id": entry.entity_id,
    }
    assert update_events[1].data == {
        "action": "remove",
        "entity_id": entry.entity_id,
    }


async def test_enabled_count_for_config_entry(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test counting enabled entries for a config entry."""
    mock_config = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config.add_to_hass(hass)

    def enabled_count() -> int:
        return entity_registry.entities.get_enabled_count_for_config_entry_id(
            "mock-id-1"
        )

    assert enabled_count() == 0

    # Enabled entry increments the count
    entry1 = entity_registry.async_get_or_create(
        "light", "hue", "1", config_entry=mock_config
    )
    assert enabled_count() == 1

    # Disabled-by-default entry does not count
    entity_registry.async_get_or_create(
        "light",
        "hue",
        "2",
        config_entry=mock_config,
        disabled_by=er.RegistryEntryDisabler.INTEGRATION,
    )
    assert enabled_count() == 1

    # Disabling an enabled entry decrements the count
    entity_registry.async_update_entity(
        entry1.entity_id, disabled_by=er.RegistryEntryDisabler.USER
    )
    assert enabled_count() == 0

    # Re-enabling increments it again
    entity_registry.async_update_entity(entry1.entity_id, disabled_by=None)
    assert enabled_count() == 1

    # Removing an enabled entry decrements the count
    entity_registry.async_remove(entry1.entity_id)
    assert enabled_count() == 0

    # The count matches a filtered scan of the index
    entity_registry.async_get_or_create("light", "hue", "3", config_entry=mock_config)
    entity_registry.async_get_or_create("light", "hue", "4", config_entry=mock_config)
    assert enabled_count() == len(
        [
            entry
            for entry in entity_registry.entities.get_entries_for_config_entry_id(
                "mock-id-1"
            )
            if not entry.disabled
        ]
    )


async def test_deleted_entity_removing_config_entry_id(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that we update config entry id in registry on deleted entity."""
    mock_config1 = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config2 = MockConfigEntry(domain="light", entry_id="mock-id-2")
    mock_config1.add_to_hass(hass)
    mock_config2.add_to_hass(hass)

    entry1 = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config1
    )
    assert entry1.config_entry_id == "mock-id-1"
    entry2 = entity_registry.async_get_or_create(
        "light", "hue", "1234", config_entry=mock_config2
    )
    assert entry2.config_entry_id == "mock-id-2"
    entity_registry.async_remove(entry1.entity_id)
    entity_registry.async_remove(entry2.entity_id)

    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 2
    deleted_entry1 = entity_registry.deleted_entities[("light", "hue", "5678")]
    assert deleted_entry1.config_entry_id == "mock-id-1"
    assert deleted_entry1.orphaned_timestamp is None
    deleted_entry2 = entity_registry.deleted_entities[("light", "hue", "1234")]
    assert deleted_entry2.config_entry_id == "mock-id-2"
    assert deleted_entry2.orphaned_timestamp is None

    entity_registry.async_clear_config_entry("mock-id-1")
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 2
    deleted_entry1 = entity_registry.deleted_entities[("light", "hue", "5678")]
    assert deleted_entry1.config_entry_id is None
    assert deleted_entry1.orphaned_timestamp is not None
    assert entity_registry.deleted_entities[("light", "hue", "1234")] == deleted_entry2


async def test_removing_config_subentry_id(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test that we update config subentry id in registry."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    mock_config = MockConfigEntry(
        domain="light",
        entry_id="mock-id-1",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            )
        ],
    )
    mock_config.add_to_hass(hass)

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=mock_config,
        config_subentry_id="mock-subentry-id-1",
    )
    assert entry.config_subentry_id == "mock-subentry-id-1"
    hass.config_entries.async_remove_subentry(mock_config, "mock-subentry-id-1")

    assert not entity_registry.entities

    await hass.async_block_till_done()

    assert len(update_events) == 2
    assert update_events[0].data == {
        "action": "create",
        "entity_id": entry.entity_id,
    }
    assert update_events[1].data == {
        "action": "remove",
        "entity_id": entry.entity_id,
    }


async def test_deleted_entity_removing_config_subentry_id(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that we update config subentry id in registry on deleted entity."""
    mock_config = MockConfigEntry(
        domain="light",
        entry_id="mock-id-1",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    mock_config.add_to_hass(hass)

    entry1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=mock_config,
        config_subentry_id="mock-subentry-id-1",
    )
    assert entry1.config_subentry_id == "mock-subentry-id-1"
    entry2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        config_entry=mock_config,
        config_subentry_id="mock-subentry-id-2",
    )
    assert entry2.config_subentry_id == "mock-subentry-id-2"
    entity_registry.async_remove(entry1.entity_id)
    entity_registry.async_remove(entry2.entity_id)

    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 2
    deleted_entry1 = entity_registry.deleted_entities[("light", "hue", "5678")]
    assert deleted_entry1.config_entry_id == "mock-id-1"
    assert deleted_entry1.config_subentry_id == "mock-subentry-id-1"
    assert deleted_entry1.orphaned_timestamp is None
    deleted_entry2 = entity_registry.deleted_entities[("light", "hue", "1234")]
    assert deleted_entry2.config_entry_id == "mock-id-1"
    assert deleted_entry2.config_subentry_id == "mock-subentry-id-2"
    assert deleted_entry2.orphaned_timestamp is None

    hass.config_entries.async_remove_subentry(mock_config, "mock-subentry-id-1")
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 2
    deleted_entry1 = entity_registry.deleted_entities[("light", "hue", "5678")]
    assert deleted_entry1.config_entry_id is None
    assert deleted_entry1.config_subentry_id is None
    assert deleted_entry1.orphaned_timestamp is not None
    assert entity_registry.deleted_entities[("light", "hue", "1234")] == deleted_entry2


async def test_removing_area_id(entity_registry: er.EntityRegistry) -> None:
    """Make sure we can clear area id."""
    entry = entity_registry.async_get_or_create("light", "hue", "5678")

    entry_w_area = entity_registry.async_update_entity(
        entry.entity_id, area_id="12345A"
    )

    entity_registry.async_clear_area_id("12345A")
    entry_wo_area = entity_registry.async_get(entry.entity_id)

    assert not entry_wo_area.area_id
    assert entry_w_area != entry_wo_area


async def test_removing_area_id_deleted_entity(
    entity_registry: er.EntityRegistry,
) -> None:
    """Make sure we can clear area id."""
    entry1 = entity_registry.async_get_or_create("light", "hue", "5678")
    entry2 = entity_registry.async_get_or_create("light", "hue", "1234")

    entry1_w_area = entity_registry.async_update_entity(
        entry1.entity_id, area_id="12345A"
    )
    entry2_w_area = entity_registry.async_update_entity(
        entry2.entity_id, area_id="12345B"
    )

    entity_registry.async_remove(entry1.entity_id)
    entity_registry.async_remove(entry2.entity_id)

    entity_registry.async_clear_area_id("12345A")
    entry1_restored = entity_registry.async_get_or_create("light", "hue", "5678")
    entry2_restored = entity_registry.async_get_or_create("light", "hue", "1234")

    assert not entry1_restored.area_id
    assert entry2_restored.area_id == "12345B"
    assert entry1_w_area != entry1_restored
    assert entry2_w_area != entry2_restored


@pytest.mark.parametrize("load_registries", [False])
async def test_migration_1_1(hass: HomeAssistant, hass_storage: dict[str, Any]) -> None:
    """Test migration from version 1.1."""
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    "device_class": "best_class",
                    "entity_id": "test.entity",
                    "platform": "super_platform",
                    "unique_id": "very_unique",
                },
            ]
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)

    await er.async_load(hass)
    registry = er.async_get(hass)

    entry = registry.async_get_or_create("test", "super_platform", "very_unique")

    assert entry.device_class is None
    assert entry.original_device_class == "best_class"

    # Check migrated data
    await flush_store(registry._store)
    migrated_data = hass_storage[er.STORAGE_KEY]
    assert migrated_data == {
        "version": er.STORAGE_VERSION_MAJOR,
        "minor_version": er.STORAGE_VERSION_MINOR,
        "key": er.STORAGE_KEY,
        "data": {
            "entities": [
                {
                    "aliases": [],
                    "aliases_v2": [None],
                    "area_id": None,
                    "capabilities": {},
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "device_id": None,
                    "disabled_by": None,
                    "entity_category": None,
                    "entity_id": "test.entity",
                    "has_entity_name": False,
                    "hidden_by": None,
                    "icon": None,
                    "id": ANY,
                    "labels": [],
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "object_id_base": None,
                    "options": {},
                    "original_device_class": "best_class",
                    "original_icon": None,
                    "original_name": None,
                    "platform": "super_platform",
                    "previous_unique_id": None,
                    "suggested_object_id": None,
                    "supported_features": 0,
                    "translation_key": None,
                    "unique_id": "very_unique",
                    "unit_of_measurement": None,
                    "device_class": None,
                }
            ],
            "deleted_entities": [],
            "settings": {"entity_id_parts": None},
        },
    }

    # Serialize the migrated data again
    registry.async_schedule_save()
    await flush_store(registry._store)
    assert hass_storage[er.STORAGE_KEY] == migrated_data


@pytest.mark.parametrize("load_registries", [False])
async def test_migration_1_7(hass: HomeAssistant, hass_storage: dict[str, Any]) -> None:
    """Test migration from version 1.7.

    This tests cleanup after frontend bug which incorrectly updated device_class
    """
    entity_dict = {
        "area_id": None,
        "capabilities": {},
        "config_entry_id": None,
        "device_id": None,
        "disabled_by": None,
        "entity_category": None,
        "has_entity_name": False,
        "hidden_by": None,
        "icon": None,
        "id": "12345",
        "name": None,
        "options": None,
        "original_icon": None,
        "original_name": None,
        "platform": "super_platform",
        "supported_features": 0,
        "unique_id": "very_unique",
        "unit_of_measurement": None,
    }

    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 7,
        "data": {
            "entities": [
                {
                    **entity_dict,
                    "device_class": "original_class_by_integration",
                    "entity_id": "test.entity",
                    "original_device_class": "new_class_by_integration",
                },
                {
                    **entity_dict,
                    "device_class": "class_by_user",
                    "entity_id": "binary_sensor.entity",
                    "original_device_class": "class_by_integration",
                },
                {
                    **entity_dict,
                    "device_class": "class_by_user",
                    "entity_id": "cover.entity",
                    "original_device_class": "class_by_integration",
                },
            ]
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)

    await er.async_load(hass)
    registry = er.async_get(hass)

    entry = registry.async_get_or_create("test", "super_platform", "very_unique")
    assert entry.device_class is None
    assert entry.original_device_class == "new_class_by_integration"

    entry = registry.async_get_or_create(
        "binary_sensor", "super_platform", "very_unique"
    )
    assert entry.device_class == "class_by_user"
    assert entry.original_device_class == "class_by_integration"

    entry = registry.async_get_or_create("cover", "super_platform", "very_unique")
    assert entry.device_class == "class_by_user"
    assert entry.original_device_class == "class_by_integration"


@pytest.mark.parametrize("load_registries", [False])
async def test_migration_1_11(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """Test migration from version 1.11.

    This is the first version which has deleted entities, make sure deleted entities
    are updated.
    """
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 11,
        "data": {
            "entities": [
                {
                    "aliases": [],
                    "area_id": None,
                    "capabilities": {},
                    "config_entry_id": None,
                    "device_id": None,
                    "disabled_by": None,
                    "entity_category": None,
                    "entity_id": "test.entity",
                    "has_entity_name": False,
                    "hidden_by": None,
                    "icon": None,
                    "id": "12345",
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "options": {},
                    "original_device_class": "best_class",
                    "original_icon": None,
                    "original_name": None,
                    "platform": "super_platform",
                    "supported_features": 0,
                    "translation_key": None,
                    "unique_id": "very_unique",
                    "unit_of_measurement": None,
                    "device_class": None,
                }
            ],
            "deleted_entities": [
                {
                    "config_entry_id": None,
                    "entity_id": "test.deleted_entity",
                    "id": "23456",
                    "orphaned_timestamp": None,
                    "platform": "super_duper_platform",
                    "unique_id": "very_very_unique",
                }
            ],
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)

    await er.async_load(hass)
    registry = er.async_get(hass)

    entry = registry.async_get_or_create("test", "super_platform", "very_unique")

    assert entry.device_class is None
    assert entry.original_device_class == "best_class"

    deleted_entry = registry.deleted_entities[
        ("test", "super_duper_platform", "very_very_unique")
    ]
    assert deleted_entry.disabled_by is UNDEFINED
    assert deleted_entry.hidden_by is UNDEFINED
    assert deleted_entry.options is UNDEFINED

    # Check migrated data
    await flush_store(registry._store)
    migrated_data = hass_storage[er.STORAGE_KEY]
    assert migrated_data == {
        "version": er.STORAGE_VERSION_MAJOR,
        "minor_version": er.STORAGE_VERSION_MINOR,
        "key": er.STORAGE_KEY,
        "data": {
            "entities": [
                {
                    "aliases": [],
                    "aliases_v2": [None],
                    "area_id": None,
                    "capabilities": {},
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "device_id": None,
                    "disabled_by": None,
                    "entity_category": None,
                    "entity_id": "test.entity",
                    "has_entity_name": False,
                    "hidden_by": None,
                    "icon": None,
                    "id": ANY,
                    "labels": [],
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "object_id_base": None,
                    "options": {},
                    "original_device_class": "best_class",
                    "original_icon": None,
                    "original_name": None,
                    "platform": "super_platform",
                    "previous_unique_id": None,
                    "suggested_object_id": None,
                    "supported_features": 0,
                    "translation_key": None,
                    "unique_id": "very_unique",
                    "unit_of_measurement": None,
                    "device_class": None,
                }
            ],
            "deleted_entities": [
                {
                    "aliases": [],
                    "aliases_v2": [None],
                    "area_id": None,
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "device_class": None,
                    "disabled_by": None,
                    "disabled_by_undefined": True,
                    "entity_id": "test.deleted_entity",
                    "hidden_by": None,
                    "hidden_by_undefined": True,
                    "icon": None,
                    "id": "23456",
                    "labels": [],
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "options": {},
                    "options_undefined": True,
                    "orphaned_timestamp": None,
                    "platform": "super_duper_platform",
                    "unique_id": "very_very_unique",
                }
            ],
            "settings": {"entity_id_parts": None},
        },
    }

    # Serialize the migrated data again
    registry.async_schedule_save()
    await flush_store(registry._store)
    assert hass_storage[er.STORAGE_KEY] == migrated_data


@pytest.mark.parametrize("load_registries", [False])
async def test_migration_1_18(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """Test migration from version 1.18.

    This version has a flawed migration.
    """
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 18,
        "data": {
            "entities": [
                {
                    "aliases": [],
                    "area_id": None,
                    "capabilities": {},
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "device_id": None,
                    "disabled_by": None,
                    "entity_category": None,
                    "entity_id": "test.entity",
                    "has_entity_name": False,
                    "hidden_by": None,
                    "icon": None,
                    "id": "12345",
                    "labels": [],
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "options": {},
                    "original_device_class": "best_class",
                    "original_icon": None,
                    "original_name": "Test Entity",
                    "platform": "super_platform",
                    "previous_unique_id": None,
                    "suggested_object_id": None,
                    "supported_features": 0,
                    "translation_key": None,
                    "unique_id": "very_unique",
                    "unit_of_measurement": None,
                    "device_class": None,
                }
            ],
            "deleted_entities": [
                {
                    "aliases": [],
                    "area_id": None,
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "device_class": None,
                    "disabled_by": None,
                    "entity_id": "test.deleted_entity",
                    "hidden_by": None,
                    "icon": None,
                    "id": "23456",
                    "labels": [],
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "options": {},
                    "orphaned_timestamp": None,
                    "platform": "super_duper_platform",
                    "unique_id": "very_very_unique",
                }
            ],
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)

    await er.async_load(hass)
    registry = er.async_get(hass)

    entry = registry.async_get_or_create("test", "super_platform", "very_unique")

    assert entry.device_class is None
    assert entry.original_device_class == "best_class"

    deleted_entry = registry.deleted_entities[
        ("test", "super_duper_platform", "very_very_unique")
    ]
    assert deleted_entry.disabled_by is None
    assert deleted_entry.hidden_by is None
    assert deleted_entry.options == {}

    # Check migrated data
    await flush_store(registry._store)
    migrated_data = hass_storage[er.STORAGE_KEY]
    assert migrated_data == {
        "version": er.STORAGE_VERSION_MAJOR,
        "minor_version": er.STORAGE_VERSION_MINOR,
        "key": er.STORAGE_KEY,
        "data": {
            "entities": [
                {
                    "aliases": [],
                    "aliases_v2": [None],
                    "area_id": None,
                    "capabilities": {},
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "device_id": None,
                    "disabled_by": None,
                    "entity_category": None,
                    "entity_id": "test.entity",
                    "has_entity_name": False,
                    "hidden_by": None,
                    "icon": None,
                    "id": ANY,
                    "labels": [],
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "object_id_base": "Test Entity",
                    "options": {},
                    "original_device_class": "best_class",
                    "original_icon": None,
                    "original_name": "Test Entity",
                    "platform": "super_platform",
                    "previous_unique_id": None,
                    "suggested_object_id": None,
                    "supported_features": 0,
                    "translation_key": None,
                    "unique_id": "very_unique",
                    "unit_of_measurement": None,
                    "device_class": None,
                }
            ],
            "deleted_entities": [
                {
                    "aliases": [],
                    "aliases_v2": [None],
                    "area_id": None,
                    "categories": {},
                    "config_entry_id": None,
                    "config_subentry_id": None,
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "device_class": None,
                    "disabled_by": None,
                    "disabled_by_undefined": False,
                    "entity_id": "test.deleted_entity",
                    "hidden_by": None,
                    "hidden_by_undefined": False,
                    "icon": None,
                    "id": "23456",
                    "labels": [],
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name": None,
                    "options": {},
                    "options_undefined": False,
                    "orphaned_timestamp": None,
                    "platform": "super_duper_platform",
                    "unique_id": "very_very_unique",
                }
            ],
            "settings": {"entity_id_parts": None},
        },
    }

    # Serialize the migrated data again
    registry.async_schedule_save()
    await flush_store(registry._store)
    assert hass_storage[er.STORAGE_KEY] == migrated_data


@pytest.mark.parametrize("load_registries", [False])
async def test_migration_1_21(
    hass: HomeAssistant,
    hass_storage: dict[str, Any],
) -> None:
    """Test migration from version 1.21.

    Version 1.21 stored entity names in a new format, but was reverted.
    """
    hass_storage[dr.STORAGE_KEY] = {
        "version": dr.STORAGE_VERSION_MAJOR,
        "minor_version": dr.STORAGE_VERSION_MINOR,
        "data": {
            "child_devices": [],
            "devices": [
                {
                    "area_id": None,
                    "config_entries": ["mock_entry"],
                    "config_entries_subentries": {"mock_entry": [None]},
                    "config_entry_id": "mock_entry",
                    "config_subentry_id": None,
                    "composite_device_id": None,
                    "composite_primary_config_entry": None,
                    "split_at": None,
                    "has_composite_identifiers": False,
                    "configuration_url": None,
                    "connections": [],
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "disabled_by": None,
                    "disabled_by_undefined": False,
                    "entry_type": None,
                    "hw_version": None,
                    "id": "device_1234",
                    "identifiers": [["test", "device_1"]],
                    "labels": [],
                    "manufacturer": None,
                    "model": None,
                    "model_id": None,
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name_by_user": None,
                    "name": "My Device",
                    "primary_config_entry": "mock_entry",
                    "serial_number": None,
                    "sw_version": None,
                    "via_device_id": None,
                },
            ],
            "deleted_devices": [],
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)

    entity_base = {
        "aliases": [],
        "area_id": None,
        "capabilities": {},
        "categories": {},
        "config_entry_id": None,
        "config_subentry_id": None,
        "created_at": "1970-01-01T00:00:00+00:00",
        "device_id": "device_1234",
        "disabled_by": None,
        "entity_category": None,
        "has_entity_name": False,
        "hidden_by": None,
        "icon": None,
        "labels": [],
        "modified_at": "1970-01-01T00:00:00+00:00",
        "object_id_base": "Temperature",
        "options": {},
        "original_device_class": "temperature",
        "original_icon": None,
        "original_name": "Temperature",
        "platform": "super_platform",
        "previous_unique_id": None,
        "suggested_object_id": None,
        "supported_features": 0,
        "translation_key": None,
        "unit_of_measurement": None,
        "device_class": None,
    }
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 21,
        "data": {
            "entities": [
                {
                    **entity_base,
                    "entity_id": "test.custom_name",
                    "id": "entity_custom_name",
                    "unique_id": "custom_name",
                    "name": "My Custom Name",
                    "name_v2": "My Custom Name",
                },
                {
                    **entity_base,
                    "entity_id": "test.stripped",
                    "id": "entity_stripped",
                    "unique_id": "stripped",
                    "name": "My Device Temperature",
                    "name_v2": "Temperature",
                },
                {
                    **entity_base,
                    "entity_id": "test.stripped_and_renamed",
                    "id": "entity_stripped_and_renamed",
                    "unique_id": "stripped_and_renamed",
                    "name": "My Device Temperature",
                    "name_v2": "Heat",
                },
            ],
            "deleted_entities": [],
        },
    }

    await er.async_load(hass)
    registry = er.async_get(hass)

    entry = registry.async_get_or_create("test", "super_platform", "custom_name")
    assert entry.name == "My Custom Name"

    entry = registry.async_get_or_create("test", "super_platform", "stripped")
    assert entry.name == "My Device Temperature"

    entry = registry.async_get_or_create(
        "test", "super_platform", "stripped_and_renamed"
    )
    assert entry.name == "My Device Heat"

    # Check migrated data
    await flush_store(registry._store)
    migrated_data = hass_storage[er.STORAGE_KEY]

    migrated_entity_base = {
        "aliases": [],
        "aliases_v2": [None],
        "area_id": None,
        "capabilities": {},
        "categories": {},
        "config_entry_id": None,
        "config_subentry_id": None,
        "created_at": "1970-01-01T00:00:00+00:00",
        "device_id": "device_1234",
        "disabled_by": None,
        "entity_category": None,
        "has_entity_name": False,
        "hidden_by": None,
        "icon": None,
        "labels": [],
        "modified_at": "1970-01-01T00:00:00+00:00",
        "object_id_base": "Temperature",
        "options": {},
        "original_device_class": "temperature",
        "original_icon": None,
        "original_name": "Temperature",
        "platform": "super_platform",
        "previous_unique_id": None,
        "suggested_object_id": None,
        "supported_features": 0,
        "translation_key": None,
        "unit_of_measurement": None,
        "device_class": None,
    }
    assert migrated_data == {
        "version": er.STORAGE_VERSION_MAJOR,
        "minor_version": er.STORAGE_VERSION_MINOR,
        "key": er.STORAGE_KEY,
        "data": {
            "entities": [
                {
                    **migrated_entity_base,
                    "entity_id": "test.custom_name",
                    "id": "entity_custom_name",
                    "unique_id": "custom_name",
                    "name": "My Custom Name",
                },
                {
                    **migrated_entity_base,
                    "entity_id": "test.stripped",
                    "id": "entity_stripped",
                    "unique_id": "stripped",
                    "name": "My Device Temperature",
                },
                {
                    **migrated_entity_base,
                    "entity_id": "test.stripped_and_renamed",
                    "id": "entity_stripped_and_renamed",
                    "unique_id": "stripped_and_renamed",
                    "name": "My Device Heat",
                },
            ],
            "deleted_entities": [],
            "settings": {"entity_id_parts": None},
        },
    }

    # Serialize the migrated data again
    registry.async_schedule_save()
    await flush_store(registry._store)
    assert hass_storage[er.STORAGE_KEY] == migrated_data


async def test_update_entity_unique_id(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test entity's unique_id is updated."""
    mock_config = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config.add_to_hass(hass)

    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config
    )
    assert (
        entity_registry.async_get_entity_id("light", "hue", "5678") == entry.entity_id
    )

    new_unique_id = "1234"
    with patch.object(entity_registry, "async_schedule_save") as mock_schedule_save:
        updated_entry = entity_registry.async_update_entity(
            entry.entity_id, new_unique_id=new_unique_id
        )
    assert updated_entry != entry
    assert updated_entry.unique_id == new_unique_id
    assert updated_entry.previous_unique_id == "5678"
    assert mock_schedule_save.call_count == 1

    assert entity_registry.async_get_entity_id("light", "hue", "5678") is None
    assert (
        entity_registry.async_get_entity_id("light", "hue", "1234") == entry.entity_id
    )


async def test_update_entity_unique_id_conflict(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test migration raises when unique_id already in use."""
    mock_config = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config.add_to_hass(hass)
    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config
    )
    entry2 = entity_registry.async_get_or_create(
        "light", "hue", "1234", config_entry=mock_config
    )
    with (
        patch.object(entity_registry, "async_schedule_save") as mock_schedule_save,
        pytest.raises(ValueError),
    ):
        entity_registry.async_update_entity(
            entry.entity_id, new_unique_id=entry2.unique_id
        )
    assert mock_schedule_save.call_count == 0
    assert (
        entity_registry.async_get_entity_id("light", "hue", "5678") == entry.entity_id
    )
    assert (
        entity_registry.async_get_entity_id("light", "hue", "1234") == entry2.entity_id
    )


async def test_update_entity_entity_id(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test entity's entity_id is updated for entity with a restored state."""
    hass.set_state(CoreState.not_running)

    mock_config = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config.add_to_hass(hass)
    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config
    )
    hass.bus.async_fire(EVENT_HOMEASSISTANT_START, {})
    await hass.async_block_till_done()
    assert (
        entity_registry.async_get_entity_id("light", "hue", "5678") == entry.entity_id
    )
    state = hass.states.get(entry.entity_id)
    assert state is not None
    assert state.state == "unavailable"
    assert state.attributes == {"restored": True, "supported_features": 0}

    new_entity_id = "light.blah"
    assert new_entity_id != entry.entity_id
    with patch.object(entity_registry, "async_schedule_save") as mock_schedule_save:
        updated_entry = entity_registry.async_update_entity(
            entry.entity_id, new_entity_id=new_entity_id
        )
    assert updated_entry != entry
    assert updated_entry.entity_id == new_entity_id
    assert mock_schedule_save.call_count == 1

    assert entity_registry.async_get(entry.entity_id) is None
    assert entity_registry.async_get(new_entity_id) is not None

    # The restored state should be removed
    old_state = hass.states.get(entry.entity_id)
    assert old_state is None

    # The new entity should have an unavailable initial state
    new_state = hass.states.get(new_entity_id)
    assert new_state is not None
    assert new_state.state == "unavailable"


async def test_update_entity_entity_id_without_state(
    entity_registry: er.EntityRegistry,
) -> None:
    """Test entity's entity_id is updated for entity without a state."""
    entry = entity_registry.async_get_or_create("light", "hue", "5678")

    assert (
        entity_registry.async_get_entity_id("light", "hue", "5678") == entry.entity_id
    )

    new_entity_id = "light.blah"
    assert new_entity_id != entry.entity_id
    with patch.object(entity_registry, "async_schedule_save") as mock_schedule_save:
        updated_entry = entity_registry.async_update_entity(
            entry.entity_id, new_entity_id=new_entity_id
        )
    assert updated_entry != entry
    assert updated_entry.entity_id == new_entity_id
    assert mock_schedule_save.call_count == 1

    assert entity_registry.async_get(entry.entity_id) is None
    assert entity_registry.async_get(new_entity_id) is not None


async def test_update_entity_entity_id_entity_id(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test update raises when entity_id already in use."""
    entry = entity_registry.async_get_or_create("light", "hue", "5678")
    entry2 = entity_registry.async_get_or_create("light", "hue", "1234")
    state_entity_id = "light.blah"
    hass.states.async_set(state_entity_id, "on")
    assert entry.entity_id != state_entity_id
    assert entry2.entity_id != state_entity_id

    # Try updating to a registered entity_id
    with (
        patch.object(entity_registry, "async_schedule_save") as mock_schedule_save,
        pytest.raises(ValueError),
    ):
        entity_registry.async_update_entity(
            entry.entity_id, new_entity_id=entry2.entity_id
        )
    assert mock_schedule_save.call_count == 0
    assert (
        entity_registry.async_get_entity_id("light", "hue", "5678") == entry.entity_id
    )
    assert entity_registry.async_get(entry.entity_id) is entry
    assert (
        entity_registry.async_get_entity_id("light", "hue", "1234") == entry2.entity_id
    )
    assert entity_registry.async_get(entry2.entity_id) is entry2

    # Try updating to an entity_id which is in the state machine
    with (
        patch.object(entity_registry, "async_schedule_save") as mock_schedule_save,
        pytest.raises(ValueError),
    ):
        entity_registry.async_update_entity(
            entry.entity_id, new_entity_id=state_entity_id
        )
    assert mock_schedule_save.call_count == 0
    assert (
        entity_registry.async_get_entity_id("light", "hue", "5678") == entry.entity_id
    )
    assert entity_registry.async_get(entry.entity_id) is entry
    assert entity_registry.async_get(state_entity_id) is None


async def test_update_entity(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test updating entity."""
    mock_config = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config.add_to_hass(hass)
    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config
    )

    for attr_name, new_value in (
        ("aliases", {"alias_1", "alias_2"}),
        ("disabled_by", er.RegistryEntryDisabler.USER),
        ("icon", "new icon"),
        ("name", "new name"),
    ):
        changes = {attr_name: new_value}
        updated_entry = entity_registry.async_update_entity(entry.entity_id, **changes)

        assert updated_entry != entry
        assert getattr(updated_entry, attr_name) == new_value
        assert getattr(updated_entry, attr_name) != getattr(entry, attr_name)

        assert (
            entity_registry.async_get_entity_id("light", "hue", "5678")
            == updated_entry.entity_id
        )
        entry = updated_entry


async def test_update_entity_recalculates_original_name_unprefixed(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
    device_registry: dr.DeviceRegistry,
) -> None:
    """Test original_name_unprefixed is recalculated when relevant fields change."""
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    device1 = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
        name="Device Bla",
    )
    device2 = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "AB:CD:EF:12:34:56")},
        name="Other",
    )

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device1.id,
        has_entity_name=False,
        original_name="Device Bla Sensor",
    )
    assert entry.original_name_unprefixed == "Sensor"

    entry = entity_registry.async_update_entity(
        entry.entity_id, original_name="Device Bla Temperature"
    )
    assert entry.original_name_unprefixed == "Temperature"

    entry = entity_registry.async_update_entity(
        entry.entity_id, original_name="Something Else"
    )
    assert entry.original_name_unprefixed is None

    entry = entity_registry.async_update_entity(
        entry.entity_id, original_name="Other Sensor"
    )
    assert entry.original_name_unprefixed is None

    entry = entity_registry.async_update_entity(entry.entity_id, device_id=device2.id)
    assert entry.original_name_unprefixed == "Sensor"

    entry = entity_registry.async_update_entity(
        entry.entity_id, original_name="Device Bla Sensor"
    )
    assert entry.original_name_unprefixed is None

    entry = entity_registry.async_update_entity(entry.entity_id, device_id=device1.id)
    assert entry.original_name_unprefixed == "Sensor"

    entry = entity_registry.async_update_entity(entry.entity_id, has_entity_name=True)
    assert entry.original_name_unprefixed is None


@pytest.mark.parametrize(
    (
        "new_config_entry_disabled_by",
        "entity_disabled_by_initial",
        "entity_disabled_by_updated",
    ),
    [
        (
            None,
            None,
            None,
        ),
        # Config entry not disabled, entity was disabled by config entry.
        # Entity not disabled when updated.
        (
            None,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
            None,
        ),
        (
            None,
            er.RegistryEntryDisabler.DEVICE,
            er.RegistryEntryDisabler.DEVICE,
        ),
        (
            None,
            er.RegistryEntryDisabler.HASS,
            er.RegistryEntryDisabler.HASS,
        ),
        (
            None,
            er.RegistryEntryDisabler.INTEGRATION,
            er.RegistryEntryDisabler.INTEGRATION,
        ),
        (
            None,
            er.RegistryEntryDisabler.USER,
            er.RegistryEntryDisabler.USER,
        ),
        # Config entry disabled, entity not disabled.
        # Entity disabled by config entry when updated.
        (
            config_entries.ConfigEntryDisabler.USER,
            None,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.DEVICE,
            er.RegistryEntryDisabler.DEVICE,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.HASS,
            er.RegistryEntryDisabler.HASS,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.INTEGRATION,
            er.RegistryEntryDisabler.INTEGRATION,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.USER,
            er.RegistryEntryDisabler.USER,
        ),
    ],
)
@pytest.mark.usefixtures("freezer")
async def test_update_entity_disabled_by(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    new_config_entry_disabled_by: config_entries.ConfigEntryDisabler | None,
    entity_disabled_by_initial: er.RegistryEntryDisabler | None,
    entity_disabled_by_updated: er.RegistryEntryDisabler | None,
) -> None:
    """Check how the disabled_by flag is treated when updating an entity."""
    config_entry_1 = MockConfigEntry(domain="light")
    config_entry_1.add_to_hass(hass)
    config_entry_2 = MockConfigEntry(
        domain="light", disabled_by=new_config_entry_disabled_by
    )
    config_entry_2.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry_1.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry_1,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_initial,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        object_id_base="original_name_1",
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )

    # Update entity
    entry_updated = entity_registry.async_update_entity(
        entry.entity_id,
        capabilities={"key2": "value2"},
        config_entry_id=config_entry_2.entry_id,
    )
    assert entry != entry_updated

    assert entry_updated == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="1234",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        categories={},
        capabilities={"key2": "value2"},
        config_entry_id=config_entry_2.entry_id,
        config_subentry_id=None,
        created_at=utcnow(),
        device_class=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_updated,
        entity_category=EntityCategory.DIAGNOSTIC,
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        icon=None,
        id=entry.id,
        labels=set(),
        modified_at=utcnow(),
        name=None,
        object_id_base="original_name_1",
        options={"test_domain": {"key1": "value1"}},
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )


@pytest.mark.parametrize(
    ("entity_disabled_by_initial", "entity_disabled_by_updated"),
    [
        (None, None),
        # Entity was disabled by config entry, entity not disabled when updated.
        (er.RegistryEntryDisabler.CONFIG_ENTRY, None),
        (er.RegistryEntryDisabler.DEVICE, er.RegistryEntryDisabler.DEVICE),
        (er.RegistryEntryDisabler.HASS, er.RegistryEntryDisabler.HASS),
        (er.RegistryEntryDisabler.INTEGRATION, er.RegistryEntryDisabler.INTEGRATION),
        (er.RegistryEntryDisabler.USER, er.RegistryEntryDisabler.USER),
    ],
)
@pytest.mark.usefixtures("freezer")
async def test_update_entity_disabled_by_2(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    entity_disabled_by_initial: er.RegistryEntryDisabler | None,
    entity_disabled_by_updated: er.RegistryEntryDisabler | None,
) -> None:
    """Check how the disabled_by flag is treated when updating an entity.

    In this test, the entity is updated without a config entry.
    """
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_initial,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        object_id_base="original_name_1",
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )

    # Update entity
    entry_updated = entity_registry.async_update_entity(
        entry.entity_id,
        capabilities={"key2": "value2"},
        config_entry_id=None,
    )

    assert entry != entry_updated
    # entity_id and user customizations are restored. new integration options are
    # respected.
    assert entry_updated == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="1234",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        categories={},
        capabilities={"key2": "value2"},
        config_entry_id=None,
        config_subentry_id=None,
        created_at=utcnow(),
        device_class=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_updated,
        entity_category=EntityCategory.DIAGNOSTIC,
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        icon=None,
        id=entry.id,
        labels=set(),
        modified_at=utcnow(),
        name=None,
        object_id_base="original_name_1",
        options={"test_domain": {"key1": "value1"}},
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )


async def test_update_entity_options(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test updating entity."""
    mock_config = MockConfigEntry(domain="light", entry_id="mock-id-1")
    mock_config.add_to_hass(hass)
    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=mock_config
    )

    entity_registry.async_update_entity_options(
        entry.entity_id, "light", {"minimum_brightness": 20}
    )
    new_entry_1 = entity_registry.async_get(entry.entity_id)

    assert entry.options == {}
    assert new_entry_1.options == {"light": {"minimum_brightness": 20}}

    # Test it's not possible to modify the options
    with pytest.raises(RuntimeError):
        new_entry_1.options["blah"] = {}
    with pytest.raises(RuntimeError):
        new_entry_1.options["light"] = {}
    with pytest.raises(RuntimeError):
        new_entry_1.options["light"]["blah"] = 123
    with pytest.raises(RuntimeError):
        new_entry_1.options["light"]["minimum_brightness"] = 123

    entity_registry.async_update_entity_options(
        entry.entity_id, "light", {"minimum_brightness": 30}
    )
    new_entry_2 = entity_registry.async_get(entry.entity_id)

    assert entry.options == {}
    assert new_entry_1.options == {"light": {"minimum_brightness": 20}}
    assert new_entry_2.options == {"light": {"minimum_brightness": 30}}


async def test_disabled_by(entity_registry: er.EntityRegistry) -> None:
    """Test that we can disable an entry when we create it."""
    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", disabled_by=er.RegistryEntryDisabler.HASS
    )
    assert entry.disabled_by is er.RegistryEntryDisabler.HASS
    assert entry.disabled is True

    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", disabled_by=er.RegistryEntryDisabler.INTEGRATION
    )
    assert entry.disabled_by is er.RegistryEntryDisabler.HASS
    assert entry.disabled is True

    entry2 = entity_registry.async_get_or_create("light", "hue", "1234")
    assert entry2.disabled_by is None
    assert entry2.disabled is False


async def test_disabled_by_config_entry_pref(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test config entry preference setting disabled_by."""
    mock_config = MockConfigEntry(
        domain="light",
        entry_id="mock-id-1",
        pref_disable_new_entities=True,
    )
    mock_config.add_to_hass(hass)
    entry = entity_registry.async_get_or_create(
        "light", "hue", "AAAA", config_entry=mock_config
    )
    assert entry.disabled_by is er.RegistryEntryDisabler.INTEGRATION

    entry2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "BBBB",
        config_entry=mock_config,
        disabled_by=er.RegistryEntryDisabler.USER,
    )
    assert entry2.disabled_by is er.RegistryEntryDisabler.USER


async def test_hidden_by(entity_registry: er.EntityRegistry) -> None:
    """Test that we can hide an entry when we create it."""
    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", hidden_by=er.RegistryEntryHider.USER
    )
    assert entry.hidden_by is er.RegistryEntryHider.USER
    assert entry.hidden is True

    entry = entity_registry.async_get_or_create(
        "light", "hue", "5678", disabled_by=er.RegistryEntryHider.INTEGRATION
    )
    assert entry.hidden_by is er.RegistryEntryHider.USER
    assert entry.hidden is True

    entry2 = entity_registry.async_get_or_create("light", "hue", "1234")
    assert entry2.hidden_by is None
    assert entry2.hidden is False


async def test_restore_states(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test restoring states."""
    hass.set_state(CoreState.not_running)

    entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        suggested_object_id="simple",
    )
    # Should not be created
    entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        suggested_object_id="disabled",
        disabled_by=er.RegistryEntryDisabler.HASS,
    )
    entity_registry.async_get_or_create(
        "light",
        "hue",
        "9012",
        suggested_object_id="all_info_set",
        capabilities={"max": 100},
        supported_features=5,
        original_device_class="mock-device-class",
        original_name="Mock Original Name",
        original_icon="hass:original-icon",
    )

    hass.bus.async_fire(EVENT_HOMEASSISTANT_START, {})
    await hass.async_block_till_done()

    simple = hass.states.get("light.simple")
    assert simple is not None
    assert simple.state == STATE_UNAVAILABLE
    assert simple.attributes == {"restored": True, "supported_features": 0}

    disabled = hass.states.get("light.disabled")
    assert disabled is None

    all_info_set = hass.states.get("light.all_info_set")
    assert all_info_set is not None
    assert all_info_set.state == STATE_UNAVAILABLE
    assert all_info_set.attributes == {
        "max": 100,
        "supported_features": 5,
        "device_class": "mock-device-class",
        "restored": True,
        "friendly_name": "Mock Original Name",
        "icon": "hass:original-icon",
    }

    entity_registry.async_remove("light.disabled")
    entity_registry.async_remove("light.simple")
    entity_registry.async_remove("light.all_info_set")

    await hass.async_block_till_done()

    assert hass.states.get("light.simple") is None
    assert hass.states.get("light.disabled") is None
    assert hass.states.get("light.all_info_set") is None


@pytest.mark.parametrize(
    ("original_name", "entity_name", "device_name_by_user", "expected_friendly_name"),
    [
        pytest.param(
            None, None, None, "Pedestal Fan", id="primary_entity_uses_device_name"
        ),
        pytest.param(
            "Temperature",
            None,
            None,
            "Pedestal Fan Temperature",
            id="entity_name_prefixed_with_device_name",
        ),
        pytest.param(
            "Pedestal Fan", "Angle", None, "Angle", id="user_rename_replaces_full_name"
        ),
        pytest.param(
            None, None, "Living Room Fan", "Living Room Fan", id="device_rename_applied"
        ),
    ],
)
async def test_restore_state_uses_device_name(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
    device_registry: dr.DeviceRegistry,
    original_name: str | None,
    entity_name: str | None,
    device_name_by_user: str | None,
    expected_friendly_name: str,
) -> None:
    """Test the restored state friendly name is composed like the live state."""
    hass.set_state(CoreState.not_running)

    config_entry = MockConfigEntry(domain="fan")
    config_entry.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
        name="Pedestal Fan",
    )
    device_registry.async_update_device(
        device_entry.id, name_by_user=device_name_by_user
    )

    entry = entity_registry.async_get_or_create(
        "fan",
        "demo",
        "1234",
        suggested_object_id="test",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=True,
        original_name=original_name,
    )
    entity_registry.async_update_entity(entry.entity_id, name=entity_name)

    hass.bus.async_fire(EVENT_HOMEASSISTANT_START, {})
    await hass.async_block_till_done()

    state = hass.states.get("fan.test")
    assert state is not None
    assert state.state == STATE_UNAVAILABLE
    assert state.attributes["friendly_name"] == expected_friendly_name


async def test_remove_device_removes_entities(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
    device_registry: dr.DeviceRegistry,
) -> None:
    """Test that we remove entities tied to a device."""
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device_entry.id,
    )

    assert entity_registry.async_is_registered(entry.entity_id)

    device_registry.async_remove_device(device_entry.id)
    await hass.async_block_till_done()

    assert not entity_registry.async_is_registered(entry.entity_id)


async def test_remove_device_with_shared_connection_removes_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test removing a device with a shared connection removes only its entities."""
    config_entry_1 = MockConfigEntry(domain="hue")
    config_entry_1.add_to_hass(hass)
    config_entry_2 = MockConfigEntry(domain="device_tracker")
    config_entry_2.add_to_hass(hass)

    # Same connections on different config entries are separate devices
    device_entry_1 = device_registry.async_get_or_create(
        config_entry_id=config_entry_1.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    device_entry_2 = device_registry.async_get_or_create(
        config_entry_id=config_entry_2.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    assert device_entry_1.id != device_entry_2.id

    # Create one entity for each device
    entry_1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry_1,
        device_id=device_entry_1.id,
    )
    entry_2 = entity_registry.async_get_or_create(
        "sensor",
        "device_tracker",
        "6789",
        config_entry=config_entry_2,
        device_id=device_entry_2.id,
    )
    assert entity_registry.async_is_registered(entry_1.entity_id)
    assert entity_registry.async_is_registered(entry_2.entity_id)

    # Removing the first device removes it along with its tied entity
    device_registry.async_remove_device(device_entry_1.id)
    await hass.async_block_till_done()

    assert not device_registry.async_get(device_entry_1.id)
    assert not entity_registry.async_is_registered(entry_1.entity_id)
    assert device_registry.async_get(device_entry_2.id)
    assert entity_registry.async_is_registered(entry_2.entity_id)

    # Removing the second device removes it along with its entity too
    device_registry.async_remove_device(device_entry_2.id)
    await hass.async_block_till_done()

    assert not device_registry.async_get(device_entry_2.id)
    assert not entity_registry.async_is_registered(entry_2.entity_id)


async def test_remove_device_keeps_other_config_entry_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test removing a device keeps entities not owned by its config entry."""
    config_entry_1 = MockConfigEntry(domain="hue")
    config_entry_1.add_to_hass(hass)
    config_entry_2 = MockConfigEntry(domain="some_helper")
    config_entry_2.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry_1.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )

    # An entity without a config entry, tied to the device
    entry_1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        device_id=device_entry.id,
    )
    # An entity with a different config entry, tied to the device
    entry_2 = entity_registry.async_get_or_create(
        "light",
        "some_helper",
        "5678",
        config_entry=config_entry_2,
        device_id=device_entry.id,
    )
    assert entry_1.entity_id != entry_2.entity_id
    assert entity_registry.async_is_registered(entry_1.entity_id)
    assert entity_registry.async_is_registered(entry_2.entity_id)

    # Removing the device
    device_registry.async_remove_device(device_entry.id)
    await hass.async_block_till_done()

    assert not device_registry.async_get(device_entry.id)
    # Entities not owned by the removed device's config entry are kept, but detached
    assert entity_registry.async_is_registered(entry_1.entity_id)
    assert entity_registry.async_is_registered(entry_2.entity_id)
    assert entity_registry.async_get(entry_1.entity_id).device_id is None
    assert entity_registry.async_get(entry_2.entity_id).device_id is None


async def test_move_device_config_entry_removes_old_entry_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Moving a device to another config entry removes the old entry's entities."""
    entry_a = MockConfigEntry(domain="hue")
    entry_a.add_to_hass(hass)
    entry_b = MockConfigEntry(domain="tado")
    entry_b.add_to_hass(hass)
    entry_c = MockConfigEntry(domain="some_helper")
    entry_c.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=entry_a.entry_id, identifiers={("hue", "1")}
    )
    # An entity owned by the departing entry A, and a helper entity of a third entry C
    entry_a_entity = entity_registry.async_get_or_create(
        "light", "hue", "a", config_entry=entry_a, device_id=device_entry.id
    )
    entry_c_entity = entity_registry.async_get_or_create(
        "sensor", "some_helper", "c", config_entry=entry_c, device_id=device_entry.id
    )

    # Move the device from entry A to entry B (an update, not a removal)
    device_registry.async_update_device(
        device_entry.id, new_config_entry_id=entry_b.entry_id
    )
    await hass.async_block_till_done()

    # A no longer owns the device, so A's entity is removed; C's helper is untouched
    assert not entity_registry.async_is_registered(entry_a_entity.entity_id)
    assert entity_registry.async_is_registered(entry_c_entity.entity_id)


@pytest.mark.parametrize("old_subentry_id", [None, "sub-1"])
async def test_move_device_config_subentry_removes_old_subentry_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    old_subentry_id: str | None,
) -> None:
    """Moving a device to another subentry removes the old subentry's entities.

    Includes a departing subentry of None (the main entry): the change is detected by the
    old config_subentry_id being present in the event, not by its truthiness.
    """
    config_entry = MockConfigEntry(
        domain="hue",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="sub-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="sub-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    config_entry.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        config_subentry_id=old_subentry_id,
        identifiers={("hue", "1")},
    )
    # Entity on the departing subentry, and one on the destination subentry sub-2
    old_entity = entity_registry.async_get_or_create(
        "light",
        "hue",
        "old",
        config_entry=config_entry,
        config_subentry_id=old_subentry_id,
        device_id=device_entry.id,
    )
    sub2_entity = entity_registry.async_get_or_create(
        "light",
        "hue",
        "2",
        config_entry=config_entry,
        config_subentry_id="sub-2",
        device_id=device_entry.id,
    )

    # Move the device to subentry sub-2 (an update, not a removal)
    device_registry.async_update_device(device_entry.id, new_config_subentry_id="sub-2")
    await hass.async_block_till_done()

    # The departing subentry's entity is removed; sub-2's entity is kept
    assert not entity_registry.async_is_registered(old_entity.entity_id)
    assert entity_registry.async_is_registered(sub2_entity.entity_id)


async def test_remove_device_removes_config_subentry_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test removing a device removes the entities tied to its config subentry."""
    config_entry_1 = MockConfigEntry(
        domain="hue",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    config_entry_1.add_to_hass(hass)

    # A device belongs to a single config subentry
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry_1.entry_id,
        config_subentry_id="mock-subentry-id-1",
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    assert device_entry.config_subentry_id == "mock-subentry-id-1"

    # Entity tied to the device's subentry
    entry_1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        config_entry=config_entry_1,
        config_subentry_id="mock-subentry-id-1",
        device_id=device_entry.id,
    )
    # Entity tied to a different subentry of the same config entry
    entry_2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry_1,
        config_subentry_id="mock-subentry-id-2",
        device_id=device_entry.id,
    )
    assert entity_registry.async_is_registered(entry_1.entity_id)
    assert entity_registry.async_is_registered(entry_2.entity_id)

    # Removing the device removes the entity tied to the device's subentry, and detaches
    # the entity tied to another subentry of the same config entry
    device_registry.async_remove_device(device_entry.id)
    await hass.async_block_till_done()

    assert not device_registry.async_get(device_entry.id)
    assert not entity_registry.async_is_registered(entry_1.entity_id)
    assert entity_registry.async_is_registered(entry_2.entity_id)
    assert entity_registry.async_get(entry_2.entity_id).device_id is None


async def test_remove_device_keeps_other_config_subentry_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test removing a device keeps entities not tied to its config subentry."""
    config_entry_1 = MockConfigEntry(
        domain="hue",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    config_entry_1.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry_1.entry_id,
        config_subentry_id="mock-subentry-id-1",
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )

    # An entity without a config entry
    entry_1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        device_id=device_entry.id,
    )
    # An entity tied to a different subentry of the same config entry
    entry_2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "abcd",
        config_entry=config_entry_1,
        config_subentry_id="mock-subentry-id-2",
        device_id=device_entry.id,
    )
    assert entity_registry.async_is_registered(entry_1.entity_id)
    assert entity_registry.async_is_registered(entry_2.entity_id)

    # Removing the device keeps entities not owned by its config subentry (one with no
    # config entry, one in another subentry) but detaches them
    device_registry.async_remove_device(device_entry.id)
    await hass.async_block_till_done()

    assert not device_registry.async_get(device_entry.id)
    assert entity_registry.async_is_registered(entry_1.entity_id)
    assert entity_registry.async_is_registered(entry_2.entity_id)
    assert entity_registry.async_get(entry_1.entity_id).device_id is None
    assert entity_registry.async_get(entry_2.entity_id).device_id is None


async def test_update_device_race(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test race when a device is created, updated and removed."""
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    # Create device
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    # Update it
    device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        identifiers={("bridgeid", "0123")},
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    # Add entity to the device
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device_entry.id,
    )

    assert entity_registry.async_is_registered(entry.entity_id)

    device_registry.async_remove_device(device_entry.id)
    await hass.async_block_till_done()

    assert not entity_registry.async_is_registered(entry.entity_id)


async def test_update_device_race_2(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test race when a device is removed.

    This test simulates the behavior of helpers which are removed when the
    source entity is removed.
    """
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    # Create device
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    # Add entity to the device, from the same config entry
    entry_same_config_entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device_entry.id,
    )
    # Add entity to the device, not from the same config entry
    entry_no_config_entry = entity_registry.async_get_or_create(
        "light",
        "helper",
        "abcd",
        device_id=device_entry.id,
    )
    # Add a third entity to the device, from the same config entry
    entry_same_config_entry_2 = entity_registry.async_get_or_create(
        "sensor",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device_entry.id,
    )

    # Add a listener to remove the 2nd entity it when 1st entity is removed
    @callback
    def on_entity_event(event: Event[er.EventEntityRegistryUpdatedData]) -> None:
        """Add entity registry updated event to the list."""
        if event.data["action"] == "remove":
            entity_registry.async_remove(entry_no_config_entry.entity_id)

    async_track_entity_registry_updated_event(
        hass, entry_same_config_entry.entity_id, on_entity_event
    )

    device_registry.async_remove_device(device_entry.id)
    await hass.async_block_till_done()

    assert not entity_registry.async_is_registered(entry_same_config_entry.entity_id)
    assert not entity_registry.async_is_registered(entry_no_config_entry.entity_id)
    assert not entity_registry.async_is_registered(entry_same_config_entry_2.entity_id)


async def test_has_entity_name_false_device_name_changes(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
    device_registry: dr.DeviceRegistry,
) -> None:
    """Test device name changes update entities with has_entity_name=False."""
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
        name="Hue Light",
    )

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=False,
        original_name="Hue Light Temperature",
    )
    assert entry.original_name_unprefixed == "Temperature"

    entry2 = entity_registry.async_get_or_create(
        "sensor",
        "hue",
        "2",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=False,
        original_name="Bulb brightness",
    )
    assert entry2.original_name_unprefixed is None

    entry3 = entity_registry.async_get_or_create(
        "sensor",
        "hue",
        "3",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=False,
        original_name="Bulb brightness",
    )
    entity_registry.async_update_entity(entry3.entity_id, name="My name")
    assert entry3.original_name_unprefixed is None

    entry4 = entity_registry.async_get_or_create(
        "sensor",
        "hue",
        "4",
        config_entry=config_entry,
        device_id=device_entry.id,
        has_entity_name=True,
        original_name="Hue Light Battery",
    )
    assert entry4.original_name_unprefixed is None

    # Integration renames device
    device_registry.async_update_device(device_entry.id, name="Something else")
    await hass.async_block_till_done()

    updated = entity_registry.async_get(entry.entity_id)
    assert updated.name is None
    assert updated.original_name_unprefixed is None

    updated2 = entity_registry.async_get(entry2.entity_id)
    assert updated2.name is None
    assert updated2.original_name_unprefixed is None

    updated3 = entity_registry.async_get(entry3.entity_id)
    assert updated3.name == "My name"
    assert updated3.original_name_unprefixed is None

    updated4 = entity_registry.async_get(entry4.entity_id)
    assert updated4.name is None
    assert updated4.original_name_unprefixed is None

    # Integration renames device to something else
    device_registry.async_update_device(device_entry.id, name="Bulb")
    await hass.async_block_till_done()

    updated = entity_registry.async_get(entry.entity_id)
    assert updated.name is None
    assert updated.original_name_unprefixed is None

    updated2 = entity_registry.async_get(entry2.entity_id)
    assert updated2.name is None
    assert updated2.original_name_unprefixed == "Brightness"

    updated3 = entity_registry.async_get(entry3.entity_id)
    assert updated3.name == "My name"
    assert updated3.original_name_unprefixed == "Brightness"

    updated4 = entity_registry.async_get(entry4.entity_id)
    assert updated4.name is None
    assert updated4.original_name_unprefixed is None

    # User renames device
    device_registry.async_update_device(device_entry.id, name_by_user="Hue")
    await hass.async_block_till_done()

    updated = entity_registry.async_get(entry.entity_id)
    assert updated.name is None
    assert updated.original_name_unprefixed == "Light Temperature"

    updated2 = entity_registry.async_get(entry2.entity_id)
    assert updated2.name == "Hue Brightness"
    assert updated2.original_name_unprefixed is None

    updated3 = entity_registry.async_get(entry3.entity_id)
    assert updated3.name == "My name"
    assert updated3.original_name_unprefixed is None

    updated4 = entity_registry.async_get(entry4.entity_id)
    assert updated4.name is None
    assert updated4.original_name_unprefixed is None


async def test_disable_device_disables_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that we disable entities tied to a device."""
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )

    entry1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device_entry.id,
    )
    entry2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "ABCD",
        config_entry=config_entry,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.USER,
    )
    entry3 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "EFGH",
        config_entry=config_entry,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.CONFIG_ENTRY,
    )

    assert not entry1.disabled
    assert entry2.disabled
    assert entry3.disabled

    device_registry.async_update_device(
        device_entry.id, disabled_by=dr.DeviceEntryDisabler.USER
    )
    await hass.async_block_till_done()

    entry1 = entity_registry.async_get(entry1.entity_id)
    assert entry1.disabled
    assert entry1.disabled_by is er.RegistryEntryDisabler.DEVICE
    entry2 = entity_registry.async_get(entry2.entity_id)
    assert entry2.disabled
    assert entry2.disabled_by is er.RegistryEntryDisabler.USER
    entry3 = entity_registry.async_get(entry3.entity_id)
    assert entry3.disabled
    assert entry3.disabled_by is er.RegistryEntryDisabler.CONFIG_ENTRY

    device_registry.async_update_device(device_entry.id, disabled_by=None)
    await hass.async_block_till_done()

    entry1 = entity_registry.async_get(entry1.entity_id)
    assert not entry1.disabled
    entry2 = entity_registry.async_get(entry2.entity_id)
    assert entry2.disabled
    assert entry2.disabled_by is er.RegistryEntryDisabler.USER
    entry3 = entity_registry.async_get(entry3.entity_id)
    assert entry3.disabled
    assert entry3.disabled_by is er.RegistryEntryDisabler.CONFIG_ENTRY


async def test_disable_config_entry_disables_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that we disable entities tied to a config entry."""
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )

    entry1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device_entry.id,
    )
    entry2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "ABCD",
        config_entry=config_entry,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.USER,
    )
    entry3 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "EFGH",
        config_entry=config_entry,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.DEVICE,
    )

    assert not entry1.disabled
    assert entry2.disabled
    assert entry3.disabled

    await hass.config_entries.async_set_disabled_by(
        config_entry.entry_id, config_entries.ConfigEntryDisabler.USER
    )
    await hass.async_block_till_done()

    entry1 = entity_registry.async_get(entry1.entity_id)
    assert entry1.disabled
    assert entry1.disabled_by is er.RegistryEntryDisabler.CONFIG_ENTRY
    entry2 = entity_registry.async_get(entry2.entity_id)
    assert entry2.disabled
    assert entry2.disabled_by is er.RegistryEntryDisabler.USER
    entry3 = entity_registry.async_get(entry3.entity_id)
    assert entry3.disabled
    assert entry3.disabled_by is er.RegistryEntryDisabler.DEVICE

    await hass.config_entries.async_set_disabled_by(config_entry.entry_id, None)
    await hass.async_block_till_done()

    entry1 = entity_registry.async_get(entry1.entity_id)
    assert not entry1.disabled
    entry2 = entity_registry.async_get(entry2.entity_id)
    assert entry2.disabled
    assert entry2.disabled_by is er.RegistryEntryDisabler.USER
    # The device was re-enabled, so entity disabled by the device will be re-enabled too
    entry3 = entity_registry.async_get(entry3.entity_id)
    assert not entry3.disabled_by


async def test_disabled_entities_excluded_from_entity_list(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test that disabled entities are excluded from async_entries_for_device."""
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)

    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )

    entry1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        device_id=device_entry.id,
    )

    entry2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "ABCD",
        config_entry=config_entry,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.USER,
    )

    entries = er.async_entries_for_device(entity_registry, device_entry.id)
    assert entries == [entry1]

    entries = er.async_entries_for_device(
        entity_registry, device_entry.id, include_disabled_entities=True
    )
    assert entries == [entry1, entry2]

    ent_reg = er.async_get(hass)
    assert ent_reg.entities.get_entries_for_device_id(device_entry.id) == [entry1]

    assert ent_reg.entities.get_entries_for_device_id(
        device_entry.id, include_disabled_entities=True
    ) == [entry1, entry2]


async def test_entity_max_length_exceeded(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test that an exception is raised when the max character length is exceeded."""

    long_domain_name = (
        "1234567890123456789012345678901234567890123456789012345678901234567890"
        "1234567890123456789012345678901234567890123456789012345678901234567890"
        "1234567890123456789012345678901234567890123456789012345678901234567890"
        "1234567890123456789012345678901234567890123456789012345678901234567890"
    )

    with pytest.raises(MaxLengthExceeded) as exc_info:
        entity_registry.async_get_available_entity_id(long_domain_name, "sensor")

    assert exc_info.value.property_name == "domain"
    assert exc_info.value.max_length == 64
    assert exc_info.value.value == long_domain_name

    # Try again but force a number to get added to the entity ID
    long_entity_id_name = (
        "1234567890123456789012345678901234567890123456789012345678901234567890"
        "1234567890123456789012345678901234567890123456789012345678901234567890"
        "1234567890123456789012345678901234567890123456789012345678901234567890"
        "1234567890123456789012345678901234567"
    )

    new_id = entity_registry.async_get_available_entity_id(
        "sensor", long_entity_id_name
    )
    assert new_id == "sensor." + long_entity_id_name[: 255 - 7]
    hass.states.async_reserve(new_id)
    new_id = entity_registry.async_get_available_entity_id(
        "sensor", long_entity_id_name
    )
    assert new_id == "sensor." + long_entity_id_name[: 255 - 7 - 2] + "_2"
    hass.states.async_reserve(new_id)
    new_id = entity_registry.async_get_available_entity_id(
        "sensor", long_entity_id_name
    )
    assert new_id == "sensor." + long_entity_id_name[: 255 - 7 - 2] + "_3"


async def test_resolve_entity_ids(entity_registry: er.EntityRegistry) -> None:
    """Test resolving entity IDs."""

    entry1 = entity_registry.async_get_or_create(
        "light", "hue", "1234", suggested_object_id="beer"
    )
    assert entry1.entity_id == "light.beer"

    entry2 = entity_registry.async_get_or_create(
        "light", "hue", "2345", suggested_object_id="milk"
    )
    assert entry2.entity_id == "light.milk"

    expected = ["light.beer", "light.milk"]
    assert (
        er.async_validate_entity_ids(entity_registry, [entry1.id, entry2.id])
        == expected
    )

    expected = ["light.beer", "light.milk"]
    assert (
        er.async_validate_entity_ids(entity_registry, ["light.beer", entry2.id])
        == expected
    )

    with pytest.raises(vol.Invalid):
        er.async_validate_entity_ids(entity_registry, ["light.beer", "bad_uuid"])

    expected = ["light.unknown"]
    assert er.async_validate_entity_ids(entity_registry, ["light.unknown"]) == expected

    with pytest.raises(vol.Invalid):
        er.async_validate_entity_ids(entity_registry, ["unknown_uuid"])


async def test_entity_registry_items(hass: HomeAssistant) -> None:
    """Test the EntityRegistryItems container."""
    entities = er.EntityRegistryItems(hass)
    assert entities.get_entity_id(("a", "b", "c")) is None
    assert entities.get_entry("abc") is None

    entry1 = RegistryEntryWithDefaults(
        entity_id="test.entity1", unique_id="1234", platform="hue"
    )
    entry2 = RegistryEntryWithDefaults(
        entity_id="test.entity2", unique_id="2345", platform="hue"
    )
    entities["test.entity1"] = entry1
    entities["test.entity2"] = entry2

    assert entities["test.entity1"] is entry1
    assert entities["test.entity2"] is entry2

    assert entities.get_entity_id(("test", "hue", "1234")) is entry1.entity_id
    assert entities.get_entry(entry1.id) is entry1
    assert entities.get_entity_id(("test", "hue", "2345")) is entry2.entity_id
    assert entities.get_entry(entry2.id) is entry2

    entities.pop("test.entity1")
    del entities["test.entity2"]

    assert entities.get_entity_id(("test", "hue", "1234")) is None
    assert entities.get_entry(entry1.id) is None
    assert entities.get_entity_id(("test", "hue", "2345")) is None
    assert entities.get_entry(entry2.id) is None


async def test_config_entry_does_not_exist(entity_registry: er.EntityRegistry) -> None:
    """Test adding an entity linked to an unknown config entry."""
    mock_config = MockConfigEntry(
        domain="light",
        entry_id="mock-id-1",
        pref_disable_new_entities=True,
    )
    with pytest.raises(ValueError):
        entity_registry.async_get_or_create(
            "light", "hue", "1234", config_entry=mock_config
        )

    entity_id = entity_registry.async_get_or_create("light", "hue", "1234").entity_id
    with pytest.raises(ValueError):
        entity_registry.async_update_entity(
            entity_id, config_entry_id=mock_config.entry_id
        )


async def test_device_does_not_exist(entity_registry: er.EntityRegistry) -> None:
    """Test adding an entity linked to an unknown device."""
    with pytest.raises(ValueError):
        entity_registry.async_get_or_create("light", "hue", "1234", device_id="blah")

    entity_id = entity_registry.async_get_or_create("light", "hue", "1234").entity_id
    with pytest.raises(ValueError):
        entity_registry.async_update_entity(entity_id, device_id="blah")


async def test_composite_device_id_ignored(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
    device_registry: dr.DeviceRegistry,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Test a request to link an entity to a composite device id is ignored.

    async_get resolves a composite id to a synthesized read-only device, but it is not a
    real device, so the request is ignored: the entity keeps its current device link and
    a warning asks the user to report an issue.
    """
    entry_1 = MockConfigEntry(domain="itg1")
    entry_1.add_to_hass(hass)
    entry_2 = MockConfigEntry(domain="itg2")
    entry_2.add_to_hass(hass)
    device_1 = device_registry.async_get_or_create(
        config_entry_id=entry_1.entry_id, identifiers={("itg1", "1")}
    )
    device_2 = device_registry.async_get_or_create(
        config_entry_id=entry_2.entry_id, identifiers={("itg2", "1")}
    )
    old_id = "composite00000000000000000000ab"
    # Simulate a migration split: both devices carry the pre-migration composite id
    device_registry.devices[device_1.id] = attr.evolve(
        device_1, composite_device_id=old_id
    )
    device_registry.devices[device_2.id] = attr.evolve(
        device_2, composite_device_id=old_id
    )
    # The composite id resolves to a synthesized device, but is not a real registry entry
    assert device_registry.async_get(old_id) is not None
    assert old_id not in device_registry.devices

    warning = f"Ignoring request to link entity from integration hue to device {old_id}"

    # A new entity is created without a device link
    entry = entity_registry.async_get_or_create(
        "light", "hue", "1234", device_id=old_id
    )
    assert entry.device_id is None
    assert warning in caplog.text

    caplog.clear()
    entry = entity_registry.async_update_entity(entry.entity_id, device_id=device_1.id)
    assert entry.device_id == device_1.id
    assert warning not in caplog.text

    # An existing entity keeps its current device link on update
    entry = entity_registry.async_update_entity(entry.entity_id, device_id=old_id)
    assert entry.device_id == device_1.id
    assert warning in caplog.text

    caplog.clear()
    # An existing entity keeps its current device link on re-registration
    entry = entity_registry.async_get_or_create(
        "light", "hue", "1234", device_id=old_id
    )
    assert entry.device_id == device_1.id
    assert warning in caplog.text


async def test_disabled_by_str_not_allowed(entity_registry: er.EntityRegistry) -> None:
    """Test we need to pass disabled by type."""
    with pytest.raises(ValueError):
        entity_registry.async_get_or_create(
            "light", "hue", "1234", disabled_by=er.RegistryEntryDisabler.USER.value
        )

    entity_id = entity_registry.async_get_or_create("light", "hue", "1234").entity_id
    with pytest.raises(ValueError):
        entity_registry.async_update_entity(
            entity_id, disabled_by=er.RegistryEntryDisabler.USER.value
        )


async def test_entity_category_str_not_allowed(
    entity_registry: er.EntityRegistry,
) -> None:
    """Test we need to pass entity category type."""
    with pytest.raises(ValueError):
        entity_registry.async_get_or_create(
            "light", "hue", "1234", entity_category=EntityCategory.DIAGNOSTIC.value
        )

    entity_id = entity_registry.async_get_or_create("light", "hue", "1234").entity_id
    with pytest.raises(ValueError):
        entity_registry.async_update_entity(
            entity_id, entity_category=EntityCategory.DIAGNOSTIC.value
        )


async def test_hidden_by_str_not_allowed(entity_registry: er.EntityRegistry) -> None:
    """Test we need to pass hidden by type."""
    with pytest.raises(ValueError):
        entity_registry.async_get_or_create(
            "light", "hue", "1234", hidden_by=er.RegistryEntryHider.USER.value
        )

    entity_id = entity_registry.async_get_or_create("light", "hue", "1234").entity_id
    with pytest.raises(ValueError):
        entity_registry.async_update_entity(
            entity_id, hidden_by=er.RegistryEntryHider.USER.value
        )


async def test_unique_id_non_hashable(entity_registry: er.EntityRegistry) -> None:
    """Test unique_id which is not hashable."""
    with pytest.raises(TypeError):
        entity_registry.async_get_or_create("light", "hue", ["not", "valid"])

    entity_id = entity_registry.async_get_or_create("light", "hue", "1234").entity_id
    with pytest.raises(TypeError):
        entity_registry.async_update_entity(entity_id, new_unique_id=["not", "valid"])


async def test_unique_id_non_string(
    entity_registry: er.EntityRegistry, caplog: pytest.LogCaptureFixture
) -> None:
    """Test unique_id which is not a string."""
    entity_registry.async_get_or_create("light", "hue", 1234)
    assert (
        "'light' from integration hue has a non string unique_id '1234', "
        "please create a bug report" in caplog.text
    )

    entity_id = entity_registry.async_get_or_create("light", "hue", "1234").entity_id
    entity_registry.async_update_entity(entity_id, new_unique_id=2345)
    assert (
        "'light' from integration hue has a non string unique_id '2345', "
        "please create a bug report" in caplog.text
    )


@pytest.mark.parametrize(
    ("create_kwargs", "migrate_kwargs", "new_subentry_id", "match"),
    [
        (
            {},
            {},
            None,
            "Unique id '1234' is already in use by 'light.light'",
        ),
        (
            {"config_subentry_id": None},
            {},
            None,
            "Unique id '1234' is already in use by 'light.light'",
        ),
        (
            {},
            {"new_config_subentry_id": None},
            None,
            "Unique id '1234' is already in use by 'light.light'",
        ),
        (
            {},
            {"new_config_subentry_id": "mock-subentry-id-2"},
            "mock-subentry-id-2",
            "Can't change config entry without changing subentry",
        ),
        (
            {"config_subentry_id": "mock-subentry-id-1"},
            {"new_config_subentry_id": None},
            None,
            "Unique id '1234' is already in use by 'light.light'",
        ),
        (
            {"config_subentry_id": "mock-subentry-id-1"},
            {"new_config_subentry_id": "mock-subentry-id-2"},
            "mock-subentry-id-2",
            "Can't change config entry without changing subentry",
        ),
    ],
)
def test_migrate_entity_to_new_platform(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
    create_kwargs: dict,
    migrate_kwargs: dict,
    new_subentry_id: str | None,
    match: str,
) -> None:
    """Test migrate_entity_to_new_platform."""
    orig_config_entry = MockConfigEntry(
        domain="light",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    orig_config_entry.add_to_hass(hass)
    orig_unique_id = "5678"

    orig_entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        orig_unique_id,
        suggested_object_id="light",
        config_entry=orig_config_entry,
        disabled_by=er.RegistryEntryDisabler.USER,
        entity_category=EntityCategory.CONFIG,
        original_device_class="mock-device-class",
        original_icon="initial-original_icon",
        original_name="initial-original_name",
        **create_kwargs,
    )
    assert entity_registry.async_get("light.light") is orig_entry
    entity_registry.async_update_entity(
        "light.light",
        name="new_name",
        icon="new_icon",
    )

    new_config_entry = MockConfigEntry(
        domain="light",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    new_config_entry.add_to_hass(hass)
    new_unique_id = "1234"

    assert entity_registry.async_update_entity_platform(
        "light.light",
        "hue2",
        new_unique_id=new_unique_id,
        new_config_entry_id=new_config_entry.entry_id,
        **migrate_kwargs,
    )

    assert not entity_registry.async_get_entity_id("light", "hue", orig_unique_id)

    assert (new_entry := entity_registry.async_get("light.light")) is not orig_entry

    assert new_entry.config_entry_id == new_config_entry.entry_id
    assert new_entry.config_subentry_id == new_subentry_id
    assert new_entry.unique_id == new_unique_id
    assert new_entry.name == "new_name"
    assert new_entry.icon == "new_icon"
    assert new_entry.platform == "hue2"

    # Test nonexisting entity
    with pytest.raises(KeyError, match="'light.not_a_real_light'"):
        entity_registry.async_update_entity_platform(
            "light.not_a_real_light",
            "hue2",
            new_unique_id=new_unique_id,
            new_config_entry_id=new_config_entry.entry_id,
        )

    # Test migrate entity without new config entry ID
    with pytest.raises(
        ValueError,
        match="new_config_entry_id required because light.light is already linked to a config entry",
    ):
        entity_registry.async_update_entity_platform(
            "light.light",
            "hue3",
        )

    with pytest.raises(ValueError, match=match):
        entity_registry.async_update_entity_platform(
            "light.light",
            "hue2",
            new_unique_id=new_unique_id,
            new_config_entry_id=new_config_entry.entry_id,
        )


async def test_migrate_entity_to_new_platform_error_handling(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test migrate_entity_to_new_platform."""
    platform = MockEntityPlatform(hass, domain="light", platform_name="hue")
    orig_config_entry = MockConfigEntry(
        domain="hue",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    orig_config_entry.add_to_hass(hass)
    platform.config_entry = orig_config_entry
    entity = MockEntity(name="Light entity", entity_id="light.light", unique_id="5678")
    await platform.async_add_entities([entity], config_subentry_id="mock-subentry-id-1")

    assert entity_registry.async_get("light.light") is not None

    new_config_entry = MockConfigEntry(
        domain="hue2",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    new_config_entry.add_to_hass(hass)
    new_unique_id = "1234"

    # Test migrating nonexisting entity
    with pytest.raises(KeyError, match="'light.not_a_real_light'"):
        entity_registry.async_update_entity_platform(
            "light.not_a_real_light",
            "hue2",
            new_unique_id=new_unique_id,
            new_config_entry_id=new_config_entry.entry_id,
        )

    with pytest.raises(
        ValueError, match="Only entities that haven't been loaded can be migrated"
    ):
        entity_registry.async_update_entity_platform(
            "light.light",
            "hue2",
            new_unique_id=new_unique_id,
            new_config_entry_id=new_config_entry.entry_id,
        )

    await platform.async_reset()

    # Test migrate entity without new config entry ID
    with pytest.raises(
        ValueError,
        match=(
            "new_config_entry_id required because"
            " light.light is already linked"
            " to a config entry"
        ),
    ):
        entity_registry.async_update_entity_platform(
            "light.light",
            "hue2",
        )

    # Test migrate entity without new config subentry ID
    with pytest.raises(
        ValueError,
        match="Can't change config entry without changing subentry",
    ):
        entity_registry.async_update_entity_platform(
            "light.light",
            "hue2",
            new_config_entry_id=new_config_entry.entry_id,
        )


async def test_restore_entity(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    freezer: FrozenDateTimeFactory,
) -> None:
    """Make sure entity registry id is stable and user configurations are restored."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    config_entry = MockConfigEntry(
        domain="light",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    config_entry.add_to_hass(hass)
    device_entry_1 = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    device_entry_2 = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "22:34:56:AB:CD:EF")},
    )
    entry1 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry,
        config_subentry_id="mock-subentry-id-1-1",
        device_id=device_entry_1.id,
        disabled_by=er.RegistryEntryDisabler.DEVICE,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        object_id_base="original_name_1",
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="suggested_1",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )
    entry2 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=config_entry,
        config_subentry_id="mock-subentry-id-1-1",
    )
    entry3 = entity_registry.async_get_or_create(
        "light",
        "hue",
        "abcd",
        disabled_by=er.RegistryEntryDisabler.INTEGRATION,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
    )

    # Apply user customizations
    entry1 = entity_registry.async_update_entity(
        entry1.entity_id,
        aliases=["alias1", "alias2"],
        area_id="12345A",
        categories={"scope1": "id", "scope2": "id"},
        device_class="device_class_user",
        disabled_by=er.RegistryEntryDisabler.USER,
        hidden_by=er.RegistryEntryHider.USER,
        icon="icon_user",
        labels={"label1", "label2"},
        name="Test Friendly Name",
        new_entity_id="light.custom_1",
    )
    entry1 = entity_registry.async_update_entity_options(
        entry1.entity_id, "options_domain", {"key": "value"}
    )

    entity_registry.async_remove(entry1.entity_id)
    entity_registry.async_remove(entry2.entity_id)
    entity_registry.async_remove(entry3.entity_id)
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 3

    # Re-add entities, integration has changed
    entry1_restored = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key2": "value2"},
        config_entry=config_entry,
        config_subentry_id="mock-subentry-id-1-2",
        device_id=device_entry_2.id,
        disabled_by=er.RegistryEntryDisabler.INTEGRATION,
        entity_category=EntityCategory.CONFIG,
        get_initial_options=lambda: {"test_domain": {"key2": "value2"}},
        has_entity_name=False,
        hidden_by=None,
        object_id_base="original_name_2",
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )
    # Add back the second entity without config entry and with different
    # disabled_by and hidden_by settings
    entry2_restored = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        disabled_by=er.RegistryEntryDisabler.INTEGRATION,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
    )
    # Add back the third entity with different disabled_by and hidden_by settings
    entry3_restored = entity_registry.async_get_or_create("light", "hue", "abcd")

    assert len(entity_registry.entities) == 3
    assert len(entity_registry.deleted_entities) == 0
    assert entry1 != entry1_restored
    # entity_id and user customizations are restored. new integration options are
    # respected.
    assert entry1_restored == er.RegistryEntry(
        entity_id="light.custom_1",
        unique_id="1234",
        platform="hue",
        aliases=["alias1", "alias2"],
        area_id="12345A",
        categories={"scope1": "id", "scope2": "id"},
        capabilities={"key2": "value2"},
        config_entry_id=config_entry.entry_id,
        config_subentry_id="mock-subentry-id-1-2",
        created_at=utcnow(),
        device_class="device_class_user",
        device_id=device_entry_2.id,
        disabled_by=er.RegistryEntryDisabler.USER,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=False,
        hidden_by=er.RegistryEntryHider.USER,
        icon="icon_user",
        id=entry1.id,
        labels={"label1", "label2"},
        modified_at=utcnow(),
        name="Test Friendly Name",
        object_id_base="original_name_2",
        options={"options_domain": {"key": "value"}, "test_domain": {"key1": "value1"}},
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )
    assert entry2 != entry2_restored
    # Config entry and subentry are not restored
    assert (
        attr.evolve(
            entry2,
            config_entry_id=None,
            config_subentry_id=None,
            disabled_by=None,
            hidden_by=None,
        )
        == entry2_restored
    )
    assert entry3 == entry3_restored

    # Remove two of the entities again, then bump time
    entity_registry.async_remove(entry1_restored.entity_id)
    entity_registry.async_remove(entry2.entity_id)
    assert len(entity_registry.entities) == 1
    assert len(entity_registry.deleted_entities) == 2
    freezer.tick(timedelta(seconds=er.ORPHANED_ENTITY_KEEP_SECONDS + 1))
    async_fire_time_changed(hass)
    await hass.async_block_till_done()

    # Re-add two entities, expect to get a new id after the purge
    # for entity w/o config entry
    entry1_restored = entity_registry.async_get_or_create(
        "light", "hue", "1234", config_entry=config_entry
    )
    entry2_restored = entity_registry.async_get_or_create("light", "hue", "5678")
    assert len(entity_registry.entities) == 3
    assert len(entity_registry.deleted_entities) == 0
    assert entry1.id == entry1_restored.id
    assert entry2.id != entry2_restored.id

    # Remove the first entity, then its config entry, finally bump time
    entity_registry.async_remove(entry1_restored.entity_id)
    assert len(entity_registry.entities) == 2
    assert len(entity_registry.deleted_entities) == 1
    entity_registry.async_clear_config_entry(config_entry.entry_id)
    freezer.tick(timedelta(seconds=er.ORPHANED_ENTITY_KEEP_SECONDS + 1))
    async_fire_time_changed(hass)
    await hass.async_block_till_done()

    # Re-add the entity, expect to get a new id after the purge
    entry1_restored = entity_registry.async_get_or_create(
        "light", "hue", "1234", config_entry=config_entry
    )
    assert len(entity_registry.entities) == 3
    assert len(entity_registry.deleted_entities) == 0
    assert entry1.id != entry1_restored.id

    # Check the events
    await hass.async_block_till_done()
    assert len(update_events) == 17
    assert update_events[0].data == {
        "action": "create",
        "entity_id": "light.suggested_1",
    }
    assert update_events[1].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[2].data == {"action": "create", "entity_id": "light.hue_abcd"}
    assert update_events[3].data["action"] == "update"
    assert update_events[4].data["action"] == "update"
    assert update_events[5].data == {"action": "remove", "entity_id": "light.custom_1"}
    assert update_events[6].data == {"action": "remove", "entity_id": "light.hue_5678"}
    assert update_events[7].data == {"action": "remove", "entity_id": "light.hue_abcd"}
    # Restore entities the 1st time
    assert update_events[8].data == {"action": "create", "entity_id": "light.custom_1"}
    assert update_events[9].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[10].data == {"action": "create", "entity_id": "light.hue_abcd"}
    assert update_events[11].data == {"action": "remove", "entity_id": "light.custom_1"}
    assert update_events[12].data == {"action": "remove", "entity_id": "light.hue_5678"}
    # Restore entities the 2nd time
    assert update_events[13].data == {"action": "create", "entity_id": "light.custom_1"}
    assert update_events[14].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[15].data == {"action": "remove", "entity_id": "light.custom_1"}
    # Restore entities the 3rd time
    assert update_events[16].data == {"action": "create", "entity_id": "light.hue_1234"}


@pytest.mark.parametrize(
    ("entity_disabled_by"),
    [
        None,
        er.RegistryEntryDisabler.CONFIG_ENTRY,
        er.RegistryEntryDisabler.DEVICE,
        er.RegistryEntryDisabler.HASS,
        er.RegistryEntryDisabler.INTEGRATION,
        er.RegistryEntryDisabler.USER,
    ],
)
@pytest.mark.usefixtures("freezer")
async def test_restore_migrated_entity_disabled_by(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    entity_disabled_by: er.RegistryEntryDisabler | None,
) -> None:
    """Check how the disabled_by flag is treated when restoring an entity."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=None,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )

    entity_registry.async_remove(entry.entity_id)
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 1

    deleted_entry = entity_registry.deleted_entities[("light", "hue", "1234")]
    entity_registry.deleted_entities[("light", "hue", "1234")] = attr.evolve(
        deleted_entry, disabled_by=UNDEFINED
    )

    # Re-add entity, integration has changed
    entry_restored = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key2": "value2"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by,
        entity_category=EntityCategory.CONFIG,
        get_initial_options=lambda: {"test_domain": {"key2": "value2"}},
        has_entity_name=False,
        hidden_by=None,
        object_id_base="original_name_2",
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    assert len(entity_registry.entities) == 1
    assert len(entity_registry.deleted_entities) == 0
    assert entry != entry_restored
    # entity_id and user customizations are restored. new integration options are
    # respected.
    assert entry_restored == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="1234",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        categories={},
        capabilities={"key2": "value2"},
        config_entry_id=config_entry.entry_id,
        config_subentry_id=None,
        created_at=utcnow(),
        device_class=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=False,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        icon=None,
        id=entry.id,
        labels=set(),
        modified_at=utcnow(),
        name=None,
        object_id_base="original_name_2",
        options={"test_domain": {"key1": "value1"}},
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    # Check the events
    await hass.async_block_till_done()
    assert len(update_events) == 3
    assert update_events[0].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[1].data == {"action": "remove", "entity_id": "light.hue_5678"}
    assert update_events[2].data == {"action": "create", "entity_id": "light.hue_5678"}


@pytest.mark.parametrize(
    ("entity_hidden_by"),
    [
        None,
        er.RegistryEntryHider.INTEGRATION,
        er.RegistryEntryHider.USER,
    ],
)
@pytest.mark.usefixtures("freezer")
async def test_restore_migrated_entity_hidden_by(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    entity_hidden_by: er.RegistryEntryHider | None,
) -> None:
    """Check how the hidden_by flag is treated when restoring an entity."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=None,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        object_id_base="original_name_1",
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )

    entity_registry.async_remove(entry.entity_id)
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 1

    deleted_entry = entity_registry.deleted_entities[("light", "hue", "1234")]
    entity_registry.deleted_entities[("light", "hue", "1234")] = attr.evolve(
        deleted_entry, hidden_by=UNDEFINED
    )

    # Re-add entity, integration has changed
    entry_restored = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key2": "value2"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=None,
        entity_category=EntityCategory.CONFIG,
        get_initial_options=lambda: {"test_domain": {"key2": "value2"}},
        has_entity_name=False,
        hidden_by=entity_hidden_by,
        object_id_base="original_name_2",
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    assert len(entity_registry.entities) == 1
    assert len(entity_registry.deleted_entities) == 0
    assert entry != entry_restored
    # entity_id and user customizations are restored. new integration options are
    # respected.
    assert entry_restored == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="1234",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        categories={},
        capabilities={"key2": "value2"},
        config_entry_id=config_entry.entry_id,
        config_subentry_id=None,
        created_at=utcnow(),
        device_class=None,
        device_id=device_entry.id,
        disabled_by=None,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=False,
        hidden_by=entity_hidden_by,
        icon=None,
        id=entry.id,
        labels=set(),
        modified_at=utcnow(),
        name=None,
        object_id_base="original_name_2",
        options={"test_domain": {"key1": "value1"}},
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    # Check the events
    await hass.async_block_till_done()
    assert len(update_events) == 3
    assert update_events[0].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[1].data == {"action": "remove", "entity_id": "light.hue_5678"}
    assert update_events[2].data == {"action": "create", "entity_id": "light.hue_5678"}


@pytest.mark.usefixtures("freezer")
async def test_restore_migrated_entity_initial_options(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Check how the initial options is treated when restoring an entity."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=None,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        object_id_base="original_name_1",
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )

    entity_registry.async_remove(entry.entity_id)
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 1

    deleted_entry = entity_registry.deleted_entities[("light", "hue", "1234")]
    entity_registry.deleted_entities[("light", "hue", "1234")] = attr.evolve(
        deleted_entry, options=UNDEFINED
    )

    # Re-add entity, integration has changed
    entry_restored = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key2": "value2"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=None,
        entity_category=EntityCategory.CONFIG,
        get_initial_options=lambda: {"test_domain": {"key2": "value2"}},
        has_entity_name=False,
        hidden_by=None,
        object_id_base="original_name_2",
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    assert len(entity_registry.entities) == 1
    assert len(entity_registry.deleted_entities) == 0
    assert entry != entry_restored
    # entity_id and user customizations are restored. new integration options are
    # respected.
    assert entry_restored == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="1234",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        categories={},
        capabilities={"key2": "value2"},
        config_entry_id=config_entry.entry_id,
        config_subentry_id=None,
        created_at=utcnow(),
        device_class=None,
        device_id=device_entry.id,
        disabled_by=None,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=False,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        icon=None,
        id=entry.id,
        labels=set(),
        modified_at=utcnow(),
        name=None,
        object_id_base="original_name_2",
        options={"test_domain": {"key2": "value2"}},
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    # Check the events
    await hass.async_block_till_done()
    assert len(update_events) == 3
    assert update_events[0].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[1].data == {"action": "remove", "entity_id": "light.hue_5678"}
    assert update_events[2].data == {"action": "create", "entity_id": "light.hue_5678"}


@pytest.mark.parametrize(
    (
        "config_entry_disabled_by",
        "entity_disabled_by_initial",
        "entity_disabled_by_restored",
    ),
    [
        (
            None,
            None,
            None,
        ),
        # Config entry not disabled, entity was disabled by config entry.
        # Entity not disabled when restored.
        (
            None,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
            None,
        ),
        (
            None,
            er.RegistryEntryDisabler.DEVICE,
            er.RegistryEntryDisabler.DEVICE,
        ),
        (
            None,
            er.RegistryEntryDisabler.HASS,
            er.RegistryEntryDisabler.HASS,
        ),
        (
            None,
            er.RegistryEntryDisabler.INTEGRATION,
            er.RegistryEntryDisabler.INTEGRATION,
        ),
        (
            None,
            er.RegistryEntryDisabler.USER,
            er.RegistryEntryDisabler.USER,
        ),
        # Config entry disabled, entity not disabled.
        # Entity disabled by config entry when restored.
        (
            config_entries.ConfigEntryDisabler.USER,
            None,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
            er.RegistryEntryDisabler.CONFIG_ENTRY,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.DEVICE,
            er.RegistryEntryDisabler.DEVICE,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.HASS,
            er.RegistryEntryDisabler.HASS,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.INTEGRATION,
            er.RegistryEntryDisabler.INTEGRATION,
        ),
        (
            config_entries.ConfigEntryDisabler.USER,
            er.RegistryEntryDisabler.USER,
            er.RegistryEntryDisabler.USER,
        ),
    ],
)
@pytest.mark.usefixtures("freezer")
async def test_restore_entity_disabled_by(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    config_entry_disabled_by: config_entries.ConfigEntryDisabler | None,
    entity_disabled_by_initial: er.RegistryEntryDisabler | None,
    entity_disabled_by_restored: er.RegistryEntryDisabler | None,
) -> None:
    """Check how the disabled_by flag is treated when restoring an entity."""
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    config_entry = MockConfigEntry(domain="light", disabled_by=config_entry_disabled_by)
    config_entry.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_initial,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        object_id_base="original_name_1",
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )

    entity_registry.async_remove(entry.entity_id)
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 1

    # Re-add entity, integration has changed
    entry_restored = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key2": "value2"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.INTEGRATION,
        entity_category=EntityCategory.CONFIG,
        get_initial_options=lambda: {"test_domain": {"key2": "value2"}},
        has_entity_name=False,
        hidden_by=None,
        object_id_base="original_name_2",
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    assert len(entity_registry.entities) == 1
    assert len(entity_registry.deleted_entities) == 0
    assert entry != entry_restored
    # entity_id and user customizations are restored. new integration options are
    # respected.
    assert entry_restored == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="1234",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        categories={},
        capabilities={"key2": "value2"},
        config_entry_id=config_entry.entry_id,
        config_subentry_id=None,
        created_at=utcnow(),
        device_class=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_restored,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=False,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        icon=None,
        id=entry.id,
        labels=set(),
        modified_at=utcnow(),
        name=None,
        object_id_base="original_name_2",
        options={"test_domain": {"key1": "value1"}},
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    # Check the events
    await hass.async_block_till_done()
    assert len(update_events) == 3
    assert update_events[0].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[1].data == {"action": "remove", "entity_id": "light.hue_5678"}
    assert update_events[2].data == {"action": "create", "entity_id": "light.hue_5678"}


@pytest.mark.parametrize(
    ("entity_disabled_by_initial", "entity_disabled_by_restored"),
    [
        (None, None),
        # Config entry not disabled, entity was disabled by config entry.
        # Entity not disabled when restored.
        (er.RegistryEntryDisabler.CONFIG_ENTRY, None),
        (er.RegistryEntryDisabler.DEVICE, er.RegistryEntryDisabler.DEVICE),
        (er.RegistryEntryDisabler.HASS, er.RegistryEntryDisabler.HASS),
        (er.RegistryEntryDisabler.INTEGRATION, er.RegistryEntryDisabler.INTEGRATION),
        (er.RegistryEntryDisabler.USER, er.RegistryEntryDisabler.USER),
    ],
)
@pytest.mark.usefixtures("freezer")
async def test_restore_entity_disabled_by_2(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
    entity_disabled_by_initial: er.RegistryEntryDisabler | None,
    entity_disabled_by_restored: er.RegistryEntryDisabler | None,
) -> None:
    """Check how the disabled_by flag is treated when restoring an entity.

    In this test, the entity is restored without a config entry.
    """
    update_events = async_capture_events(hass, er.EVENT_ENTITY_REGISTRY_UPDATED)
    config_entry = MockConfigEntry(domain="light")
    config_entry.add_to_hass(hass)
    device_entry = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        connections={(dr.CONNECTION_NETWORK_MAC, "12:34:56:AB:CD:EF")},
    )
    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key1": "value1"},
        config_entry=config_entry,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_initial,
        entity_category=EntityCategory.DIAGNOSTIC,
        get_initial_options=lambda: {"test_domain": {"key1": "value1"}},
        has_entity_name=True,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        object_id_base="original_name_1",
        original_device_class="device_class_1",
        original_icon="original_icon_1",
        original_name="original_name_1",
        suggested_object_id="hue_5678",
        supported_features=1,
        translation_key="translation_key_1",
        unit_of_measurement="unit_1",
    )

    entity_registry.async_remove(entry.entity_id)
    assert len(entity_registry.entities) == 0
    assert len(entity_registry.deleted_entities) == 1

    # Re-add entity, integration has changed
    entry_restored = entity_registry.async_get_or_create(
        "light",
        "hue",
        "1234",
        capabilities={"key2": "value2"},
        config_entry=None,
        config_subentry_id=None,
        device_id=device_entry.id,
        disabled_by=er.RegistryEntryDisabler.INTEGRATION,
        entity_category=EntityCategory.CONFIG,
        get_initial_options=lambda: {"test_domain": {"key2": "value2"}},
        has_entity_name=False,
        hidden_by=None,
        object_id_base="original_name_2",
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    assert len(entity_registry.entities) == 1
    assert len(entity_registry.deleted_entities) == 0
    assert entry != entry_restored
    # entity_id and user customizations are restored. new integration options are
    # respected.
    assert entry_restored == er.RegistryEntry(
        entity_id="light.hue_5678",
        unique_id="1234",
        platform="hue",
        aliases=[er.COMPUTED_NAME],
        area_id=None,
        categories={},
        capabilities={"key2": "value2"},
        config_entry_id=None,
        config_subentry_id=None,
        created_at=utcnow(),
        device_class=None,
        device_id=device_entry.id,
        disabled_by=entity_disabled_by_restored,
        entity_category=EntityCategory.CONFIG,
        has_entity_name=False,
        hidden_by=er.RegistryEntryHider.INTEGRATION,
        icon=None,
        id=entry.id,
        labels=set(),
        modified_at=utcnow(),
        name=None,
        object_id_base="original_name_2",
        options={"test_domain": {"key1": "value1"}},
        original_device_class="device_class_2",
        original_icon="original_icon_2",
        original_name="original_name_2",
        suggested_object_id="suggested_2",
        supported_features=2,
        translation_key="translation_key_2",
        unit_of_measurement="unit_2",
    )

    # Check the events
    await hass.async_block_till_done()
    assert len(update_events) == 3
    assert update_events[0].data == {"action": "create", "entity_id": "light.hue_5678"}
    assert update_events[1].data == {"action": "remove", "entity_id": "light.hue_5678"}
    assert update_events[2].data == {"action": "create", "entity_id": "light.hue_5678"}


async def test_async_migrate_entry_delete_self(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test async_migrate_entry."""
    config_entry1 = MockConfigEntry(domain="test1")
    config_entry2 = MockConfigEntry(domain="test2")
    config_entry1.add_to_hass(hass)
    config_entry2.add_to_hass(hass)
    entry1 = entity_registry.async_get_or_create(
        "light", "hue", "1234", config_entry=config_entry1, original_name="Entry 1"
    )
    entry2 = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=config_entry1, original_name="Entry 2"
    )
    entry3 = entity_registry.async_get_or_create(
        "light", "hue", "90AB", config_entry=config_entry2, original_name="Entry 3"
    )

    @callback
    def _async_migrator(entity_entry: er.RegistryEntry) -> dict[str, Any] | None:
        entries.add(entity_entry.entity_id)
        if entity_entry == entry1:
            entity_registry.async_remove(entry1.entity_id)
            return None
        if entity_entry == entry2:
            return {"original_name": "Entry 2 renamed"}
        return None

    entries = set()
    await er.async_migrate_entries(hass, config_entry1.entry_id, _async_migrator)
    assert entries == {entry1.entity_id, entry2.entity_id}
    assert not entity_registry.async_is_registered(entry1.entity_id)
    entry2 = entity_registry.async_get(entry2.entity_id)
    assert entry2.original_name == "Entry 2 renamed"
    assert entity_registry.async_get(entry3.entity_id) is entry3


async def test_async_migrate_entry_delete_other(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test async_migrate_entry."""
    config_entry1 = MockConfigEntry(domain="test1")
    config_entry2 = MockConfigEntry(domain="test2")
    config_entry1.add_to_hass(hass)
    config_entry2.add_to_hass(hass)
    entry1 = entity_registry.async_get_or_create(
        "light", "hue", "1234", config_entry=config_entry1, original_name="Entry 1"
    )
    entry2 = entity_registry.async_get_or_create(
        "light", "hue", "5678", config_entry=config_entry1, original_name="Entry 2"
    )
    entity_registry.async_get_or_create(
        "light", "hue", "90AB", config_entry=config_entry2, original_name="Entry 3"
    )

    @callback
    def _async_migrator(entity_entry: er.RegistryEntry) -> dict[str, Any] | None:
        entries.add(entity_entry.entity_id)
        if entity_entry == entry1:
            entity_registry.async_remove(entry2.entity_id)
            return None
        if entity_entry == entry2:
            pytest.fail("We should not get here")
        return None

    entries = set()
    await er.async_migrate_entries(hass, config_entry1.entry_id, _async_migrator)
    assert entries == {entry1.entity_id}
    assert not entity_registry.async_is_registered(entry2.entity_id)


async def test_removing_labels(entity_registry: er.EntityRegistry) -> None:
    """Make sure we can clear labels."""
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="5678",
    )
    entry = entity_registry.async_update_entity(
        entry.entity_id, labels={"label1", "label2"}
    )

    entity_registry.async_clear_label_id("label1")
    entry_cleared_label1 = entity_registry.async_get(entry.entity_id)

    entity_registry.async_clear_label_id("label2")
    entry_cleared_label2 = entity_registry.async_get(entry.entity_id)

    assert entry_cleared_label1
    assert entry_cleared_label2
    assert entry != entry_cleared_label1
    assert entry != entry_cleared_label2
    assert entry_cleared_label1 != entry_cleared_label2
    assert entry.labels == {"label1", "label2"}
    assert entry_cleared_label1.labels == {"label2"}
    assert not entry_cleared_label2.labels


async def test_removing_labels_deleted_entity(
    entity_registry: er.EntityRegistry,
) -> None:
    """Make sure we can clear labels."""
    entry1 = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="5678"
    )
    entry1 = entity_registry.async_update_entity(
        entry1.entity_id, labels={"label1", "label2"}
    )
    entry2 = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="1234"
    )
    entry2 = entity_registry.async_update_entity(entry2.entity_id, labels={"label3"})

    entity_registry.async_remove(entry1.entity_id)
    entity_registry.async_remove(entry2.entity_id)
    entity_registry.async_clear_label_id("label1")
    entry1_cleared_label1 = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="5678"
    )

    entity_registry.async_remove(entry1.entity_id)
    entity_registry.async_clear_label_id("label2")
    entry1_cleared_label2 = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="5678"
    )
    entry2_restored = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="1234"
    )

    assert entry1_cleared_label1
    assert entry1_cleared_label2
    assert entry1 != entry1_cleared_label1
    assert entry1 != entry1_cleared_label2
    assert entry1_cleared_label1 != entry1_cleared_label2
    assert entry1.labels == {"label1", "label2"}
    assert entry1_cleared_label1.labels == {"label2"}
    assert not entry1_cleared_label2.labels
    assert entry2 != entry2_restored
    assert entry2_restored.labels == {"label3"}


async def test_entries_for_label(entity_registry: er.EntityRegistry) -> None:
    """Test getting entity entries by label."""
    entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="000",
    )
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="123",
    )
    label_1 = entity_registry.async_update_entity(entry.entity_id, labels={"label1"})
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="456",
    )
    label_2 = entity_registry.async_update_entity(entry.entity_id, labels={"label2"})
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="789",
    )
    label_1_and_2 = entity_registry.async_update_entity(
        entry.entity_id, labels={"label1", "label2"}
    )

    entries = er.async_entries_for_label(entity_registry, "label1")
    assert len(entries) == 2
    assert entries == [label_1, label_1_and_2]

    entries = er.async_entries_for_label(entity_registry, "label2")
    assert len(entries) == 2
    assert entries == [label_2, label_1_and_2]

    assert not er.async_entries_for_label(entity_registry, "unknown")
    assert not er.async_entries_for_label(entity_registry, "")


async def test_removing_categories(entity_registry: er.EntityRegistry) -> None:
    """Make sure we can clear categories."""
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="5678",
    )
    entry = entity_registry.async_update_entity(
        entry.entity_id, categories={"scope1": "id", "scope2": "id"}
    )

    entity_registry.async_clear_category_id("scope1", "id")
    entry_cleared_scope1 = entity_registry.async_get(entry.entity_id)

    entity_registry.async_clear_category_id("scope2", "id")
    entry_cleared_scope2 = entity_registry.async_get(entry.entity_id)

    assert entry_cleared_scope1
    assert entry_cleared_scope2
    assert entry != entry_cleared_scope1
    assert entry != entry_cleared_scope2
    assert entry_cleared_scope1 != entry_cleared_scope2
    assert entry.categories == {"scope1": "id", "scope2": "id"}
    assert entry_cleared_scope1.categories == {"scope2": "id"}
    assert not entry_cleared_scope2.categories


async def test_removing_categories_deleted_entity(
    entity_registry: er.EntityRegistry,
) -> None:
    """Make sure we can clear categories."""
    entry = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="5678"
    )
    entry = entity_registry.async_update_entity(
        entry.entity_id, categories={"scope1": "id", "scope2": "id"}
    )

    entity_registry.async_remove(entry.entity_id)
    entity_registry.async_clear_category_id("scope1", "id")
    entry_cleared_scope1 = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="5678"
    )

    entity_registry.async_remove(entry.entity_id)
    entity_registry.async_clear_category_id("scope2", "id")
    entry_cleared_scope2 = entity_registry.async_get_or_create(
        domain="light", platform="hue", unique_id="5678"
    )

    assert entry_cleared_scope1
    assert entry_cleared_scope2
    assert entry != entry_cleared_scope1
    assert entry != entry_cleared_scope2
    assert entry_cleared_scope1 != entry_cleared_scope2
    assert entry.categories == {"scope1": "id", "scope2": "id"}
    assert entry_cleared_scope1.categories == {"scope2": "id"}
    assert not entry_cleared_scope2.categories


async def test_entries_for_category(entity_registry: er.EntityRegistry) -> None:
    """Test getting entity entries by category."""
    entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="000",
    )
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="123",
    )
    category_1 = entity_registry.async_update_entity(
        entry.entity_id, categories={"scope1": "id"}
    )
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="456",
    )
    category_2 = entity_registry.async_update_entity(
        entry.entity_id, categories={"scope2": "id"}
    )
    entry = entity_registry.async_get_or_create(
        domain="light",
        platform="hue",
        unique_id="789",
    )
    category_1_and_2 = entity_registry.async_update_entity(
        entry.entity_id, categories={"scope1": "id", "scope2": "id"}
    )

    entries = er.async_entries_for_category(entity_registry, "scope1", "id")
    assert len(entries) == 2
    assert entries == [category_1, category_1_and_2]

    entries = er.async_entries_for_category(entity_registry, "scope2", "id")
    assert len(entries) == 2
    assert entries == [category_2, category_1_and_2]

    assert not er.async_entries_for_category(entity_registry, "unknown", "id")
    assert not er.async_entries_for_category(entity_registry, "", "id")
    assert not er.async_entries_for_category(entity_registry, "scope1", "unknown")
    assert not er.async_entries_for_category(entity_registry, "scope1", "")


async def test_get_or_create_thread_safety(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test call async_get_or_create_from a thread."""
    with pytest.raises(
        RuntimeError,
        match=(
            "Detected code that calls"
            " entity_registry.async_get_or_create"
            " from a thread."
        ),
    ):
        await hass.async_add_executor_job(
            entity_registry.async_get_or_create, "light", "hue", "1234"
        )


async def test_async_update_entity_thread_safety(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test call async_get_or_create from a thread."""
    entry = entity_registry.async_get_or_create("light", "hue", "1234")
    with pytest.raises(
        RuntimeError,
        match=(
            "Detected code that calls"
            " entity_registry.async_update_entity"
            " from a thread."
        ),
    ):
        await hass.async_add_executor_job(
            partial(
                entity_registry.async_update_entity,
                entry.entity_id,
                new_unique_id="5678",
            )
        )


async def test_async_remove_thread_safety(
    hass: HomeAssistant, entity_registry: er.EntityRegistry
) -> None:
    """Test call async_remove from a thread."""
    entry = entity_registry.async_get_or_create("light", "hue", "1234")
    with pytest.raises(
        RuntimeError,
        match="Detected code that calls entity_registry.async_remove from a thread.",
    ):
        await hass.async_add_executor_job(entity_registry.async_remove, entry.entity_id)


async def test_subentry(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test subentry error handling."""
    entry1 = MockConfigEntry(
        domain="light",
        entry_id="mock-id-1",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-1-2",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            ),
        ],
    )
    entry1.add_to_hass(hass)
    entry2 = MockConfigEntry(
        domain="light",
        entry_id="mock-id-2",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-subentry-id-2-1",
                subentry_type="test",
                title="Mock title",
                unique_id="test",
            )
        ],
    )
    entry2.add_to_hass(hass)

    with pytest.raises(
        ValueError, match="Config entry mock-id-1 has no subentry bad-subentry-id"
    ):
        entry = entity_registry.async_get_or_create(
            "light",
            "hue",
            "5678",
            config_entry=entry1,
            config_subentry_id="bad-subentry-id",
        )

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=entry1,
        config_subentry_id="mock-subentry-id-1-1",
    )
    assert entry.config_subentry_id == "mock-subentry-id-1-1"

    # Try updating subentry
    with pytest.raises(
        ValueError, match="Config entry mock-id-1 has no subentry bad-subentry-id"
    ):
        entry = entity_registry.async_get_or_create(
            "light",
            "hue",
            "5678",
            config_entry=entry1,
            config_subentry_id="bad-subentry-id",
        )

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=entry1,
        config_subentry_id="mock-subentry-id-1-2",
    )
    assert entry.config_subentry_id == "mock-subentry-id-1-2"

    with pytest.raises(
        ValueError, match="Can't change config entry without changing subentry"
    ):
        entry = entity_registry.async_get_or_create(
            "light",
            "hue",
            "5678",
            config_entry=entry2,
        )

    with pytest.raises(
        ValueError, match="Config entry mock-id-2 has no subentry mock-subentry-id-1-2"
    ):
        entry = entity_registry.async_get_or_create(
            "light",
            "hue",
            "5678",
            config_entry=entry2,
            config_subentry_id="mock-subentry-id-1-2",
        )

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=entry2,
        config_subentry_id="mock-subentry-id-2-1",
    )
    assert entry.config_subentry_id == "mock-subentry-id-2-1"

    entry = entity_registry.async_get_or_create(
        "light",
        "hue",
        "5678",
        config_entry=entry1,
        config_subentry_id=None,
    )
    assert entry.config_subentry_id is None

    entry = entity_registry.async_update_entity(
        entry.entity_id,
        config_entry_id=entry2.entry_id,
        config_subentry_id="mock-subentry-id-2-1",
    )
    assert entry.config_subentry_id == "mock-subentry-id-2-1"


COMPOSITE_ID = "composite0000000000000000000000"


def _composite_device_storage(
    entry_a: MockConfigEntry, entry_b: MockConfigEntry
) -> dict[str, Any]:
    """Return a v1.10 device registry store with one composite device."""
    return {
        "version": 1,
        "minor_version": 10,
        "data": {
            "devices": [
                {
                    "area_id": "area_1",
                    "config_entries": [entry_a.entry_id, entry_b.entry_id],
                    "config_entries_subentries": {
                        entry_a.entry_id: [None],
                        entry_b.entry_id: [None],
                    },
                    "configuration_url": None,
                    "connections": [["mac", "12:34:56:ab:cd:ef"]],
                    "created_at": "1970-01-01T00:00:00+00:00",
                    "disabled_by": None,
                    "entry_type": None,
                    "hw_version": None,
                    "id": COMPOSITE_ID,
                    "identifiers": [["domain_a", "1"], ["domain_b", "1"]],
                    "labels": ["lab"],
                    "manufacturer": "man",
                    "model": "mod",
                    "name": "composite",
                    "model_id": None,
                    "modified_at": "1970-01-01T00:00:00+00:00",
                    "name_by_user": "custom name",
                    "primary_config_entry": entry_a.entry_id,
                    "serial_number": "SERIAL",
                    "sw_version": None,
                    "via_device_id": None,
                }
            ],
            "deleted_devices": [],
        },
    }


@pytest.mark.parametrize("load_registries", [False])
async def test_migration_repoints_entities(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """Entities are moved to the split device matching their config entry."""
    entry_a = MockConfigEntry(domain="domain_a")
    entry_a.add_to_hass(hass)
    entry_b = MockConfigEntry(domain="domain_b")
    entry_b.add_to_hass(hass)
    hass_storage[dr.STORAGE_KEY] = _composite_device_storage(entry_a, entry_b)
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    "entity_id": "sensor.a",
                    "platform": "domain_a",
                    "unique_id": "a",
                    "config_entry_id": entry_a.entry_id,
                    "device_id": COMPOSITE_ID,
                },
                {
                    "entity_id": "sensor.b",
                    "platform": "domain_b",
                    "unique_id": "b",
                    "config_entry_id": entry_b.entry_id,
                    "device_id": COMPOSITE_ID,
                },
            ]
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)
    await er.async_load(hass)
    device_registry = dr.async_get(hass)
    entity_registry = er.async_get(hass)

    by_entry = {
        d.config_entry_id: d.id
        for d in device_registry.async_get_devices_for_composite_device_id(COMPOSITE_ID)
    }
    assert entity_registry.async_get("sensor.a").device_id == by_entry[entry_a.entry_id]
    assert entity_registry.async_get("sensor.b").device_id == by_entry[entry_b.entry_id]


@pytest.mark.parametrize("load_registries", [False])
async def test_migration_repoints_entities_fallbacks(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """An entity not exactly matching a split falls back by config entry, then detaches."""
    entry_a = MockConfigEntry(
        domain="domain_a",
        subentries_data=[
            config_entries.ConfigSubentryData(
                data={},
                subentry_id="mock-sub",
                subentry_type="test",
                title="t",
                unique_id="u",
            )
        ],
    )
    entry_a.add_to_hass(hass)
    entry_b = MockConfigEntry(domain="domain_b")
    entry_b.add_to_hass(hass)
    # The split for entry_a is on the "mock-sub" subentry
    device_store = _composite_device_storage(entry_a, entry_b)
    device_store["data"]["devices"][0]["config_entries_subentries"] = {
        entry_a.entry_id: ["mock-sub"],
        entry_b.entry_id: [None],
    }
    hass_storage[dr.STORAGE_KEY] = device_store
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    # config entry matches a split, but the subentry does not
                    "entity_id": "sensor.sub",
                    "platform": "domain_a",
                    "unique_id": "sub",
                    "config_entry_id": entry_a.entry_id,
                    "config_subentry_id": None,
                    "device_id": COMPOSITE_ID,
                },
                {
                    # no split matches the config entry (it has none)
                    "entity_id": "sensor.none",
                    "platform": "domain_a",
                    "unique_id": "none",
                    "config_entry_id": None,
                    "device_id": COMPOSITE_ID,
                },
            ]
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)
    await er.async_load(hass)
    device_registry = dr.async_get(hass)
    entity_registry = er.async_get(hass)

    splits = device_registry.async_get_devices_for_composite_device_id(COMPOSITE_ID)
    by_entry = {d.config_entry_id: d.id for d in splits}
    # Subentry mismatch falls back to the split owning the entity's config entry
    assert (
        entity_registry.async_get("sensor.sub").device_id == by_entry[entry_a.entry_id]
    )
    # No split matches the config entry, so the entity is detached
    assert entity_registry.async_get("sensor.none").device_id is None


@pytest.mark.parametrize("load_registries", [False])
async def test_async_entries_for_device_legacy_composite_id(
    hass: HomeAssistant, hass_storage: dict[str, Any]
) -> None:
    """A legacy composite device id resolves to its split devices' entities."""
    entry_a = MockConfigEntry(domain="domain_a")
    entry_a.add_to_hass(hass)
    entry_b = MockConfigEntry(domain="domain_b")
    entry_b.add_to_hass(hass)
    hass_storage[dr.STORAGE_KEY] = _composite_device_storage(entry_a, entry_b)
    hass_storage[er.STORAGE_KEY] = {
        "version": 1,
        "minor_version": 1,
        "data": {
            "entities": [
                {
                    "entity_id": "sensor.a",
                    "platform": "domain_a",
                    "unique_id": "a",
                    "config_entry_id": entry_a.entry_id,
                    "device_id": COMPOSITE_ID,
                },
                {
                    "entity_id": "sensor.b",
                    "platform": "domain_b",
                    "unique_id": "b",
                    "config_entry_id": entry_b.entry_id,
                    "device_id": COMPOSITE_ID,
                },
            ]
        },
    }

    dr.async_setup(hass)
    await dr.async_load(hass)
    await er.async_load(hass)
    device_registry = dr.async_get(hass)
    entity_registry = er.async_get(hass)

    # The composite id is no longer a live device; its entities were repointed to splits
    assert COMPOSITE_ID not in device_registry.devices

    # get_entries_for_device_id resolves the composite id to the split entities
    assert {
        entry.entity_id
        for entry in entity_registry.entities.get_entries_for_device_id(COMPOSITE_ID)
    } == {"sensor.a", "sensor.b"}

    # The public helper resolves the composite id via the device registry
    assert {
        entry.entity_id
        for entry in er.async_entries_for_device(entity_registry, COMPOSITE_ID)
    } == {"sensor.a", "sensor.b"}

    # Disabled entities are only included when requested, across the split devices
    entity_registry.async_update_entity(
        "sensor.b", disabled_by=er.RegistryEntryDisabler.USER
    )
    assert {
        entry.entity_id
        for entry in er.async_entries_for_device(entity_registry, COMPOSITE_ID)
    } == {"sensor.a"}
    assert {
        entry.entity_id
        for entry in er.async_entries_for_device(
            entity_registry, COMPOSITE_ID, include_disabled_entities=True
        )
    } == {"sensor.a", "sensor.b"}

    # A live split device id returns just its own entity
    splits = {
        device.config_entry_id: device.id
        for device in device_registry.async_get_devices_for_composite_device_id(
            COMPOSITE_ID
        )
    }
    assert {
        entry.entity_id
        for entry in er.async_entries_for_device(
            entity_registry, splits[entry_a.entry_id]
        )
    } == {"sensor.a"}


async def test_async_entries_for_device_composite_id(
    hass: HomeAssistant,
    entity_registry: er.EntityRegistry,
    device_registry: dr.DeviceRegistry,
) -> None:
    """A pre-migration composite id resolves to the underlying devices' entities.

    Backwards compatibility for unmodified integrations: before the single-config-entry
    rewrite a shared identifier resolved to one multi-config-entry device, so
    async_entries_for_device(composite_id) returned all of that device's entities. After
    the split, the composite's virtual id must resolve to the same union so a legacy
    reference keeps working.
    """
    entry_1 = MockConfigEntry(domain="itg1")
    entry_1.add_to_hass(hass)
    entry_2 = MockConfigEntry(domain="itg2")
    entry_2.add_to_hass(hass)
    device_1 = device_registry.async_get_or_create(
        config_entry_id=entry_1.entry_id, identifiers={("itg1", "1")}
    )
    device_2 = device_registry.async_get_or_create(
        config_entry_id=entry_2.entry_id, identifiers={("itg2", "1")}
    )
    entity_1 = entity_registry.async_get_or_create(
        "sensor", "itg1", "u1", config_entry=entry_1, device_id=device_1.id
    )
    entity_2 = entity_registry.async_get_or_create(
        "sensor", "itg2", "u2", config_entry=entry_2, device_id=device_2.id
    )
    old_id = "composite00000000000000000000ab"
    # Simulate a migration split: both devices carry the pre-migration composite id
    device_registry.devices[device_1.id] = attr.evolve(
        device_1, composite_device_id=old_id
    )
    device_registry.devices[device_2.id] = attr.evolve(
        device_2, composite_device_id=old_id
    )

    assert old_id not in device_registry.devices
    assert {
        entry.entity_id
        for entry in er.async_entries_for_device(entity_registry, old_id)
    } == {entity_1.entity_id, entity_2.entity_id}


async def test_async_get_effective_area_id(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test effective area resolution for entities on child devices."""
    config_entry = MockConfigEntry(title=None)
    config_entry.add_to_hass(hass)
    parent = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip")},
        name="Power strip",
    )
    device_registry.async_update_device(parent.id, area_id="garage")
    child_device = device_registry.async_get_or_create_child(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip_outlet_1")},
        parent_device_id=parent.id,
        name="Outlet 1",
    )

    entry = entity_registry.async_get_or_create(
        "switch",
        "test",
        "outlet_1",
        config_entry=config_entry,
        device_id=child_device.id,
    )

    # The entity inherits the child device's effective area (the parent's area)
    assert er.async_get_effective_area_id(hass, entry) == "garage"

    # An explicitly set child device area overrides the inherited one
    device_registry.async_update_child_device(child_device.id, area_id="garden")
    assert er.async_get_effective_area_id(hass, entry) == "garden"

    # An explicitly set entity area overrides the device area
    entry = entity_registry.async_update_entity(entry.entity_id, area_id="attic")
    assert er.async_get_effective_area_id(hass, entry) == "attic"

    # An entity without an area and without a device has no effective area
    entry_without_device = entity_registry.async_get_or_create(
        "switch", "test", "no_device"
    )
    assert er.async_get_effective_area_id(hass, entry_without_device) is None

    # An entity whose device no longer exists has no effective area
    entry_missing_device = attr.evolve(
        entry, area_id=None, device_id="non_existent_device_id"
    )
    assert er.async_get_effective_area_id(hass, entry_missing_device) is None


async def test_disable_child_device_disables_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test disabling a parent device disables entities on its child devices."""
    config_entry = MockConfigEntry(title=None)
    config_entry.add_to_hass(hass)
    parent = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip")},
        name="Power strip",
    )
    child_device = device_registry.async_get_or_create_child(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip_outlet_1")},
        parent_device_id=parent.id,
        name="Outlet 1",
    )
    entry = entity_registry.async_get_or_create(
        "switch",
        "test",
        "outlet_1",
        config_entry=config_entry,
        device_id=child_device.id,
    )

    device_registry.async_update_device(
        parent.id, disabled_by=dr.DeviceEntryDisabler.USER
    )
    await hass.async_block_till_done()

    updated_entry = entity_registry.async_get(entry.entity_id)
    assert updated_entry is not None
    assert updated_entry.disabled_by is er.RegistryEntryDisabler.DEVICE

    device_registry.async_update_device(parent.id, disabled_by=None)
    await hass.async_block_till_done()

    updated_entry = entity_registry.async_get(entry.entity_id)
    assert updated_entry is not None
    assert updated_entry.disabled_by is None


async def test_remove_child_device_removes_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test removing a parent device removes entities on its child devices."""
    config_entry = MockConfigEntry(title=None)
    config_entry.add_to_hass(hass)
    parent = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip")},
        name="Power strip",
    )
    child_device = device_registry.async_get_or_create_child(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip_outlet_1")},
        parent_device_id=parent.id,
        name="Outlet 1",
    )
    entry = entity_registry.async_get_or_create(
        "switch",
        "test",
        "outlet_1",
        config_entry=config_entry,
        device_id=child_device.id,
    )

    device_registry.async_remove_device(parent.id)
    await hass.async_block_till_done()

    assert entity_registry.async_get(entry.entity_id) is None


async def test_remove_child_device_orphans_foreign_entry_entities(
    hass: HomeAssistant,
    device_registry: dr.DeviceRegistry,
    entity_registry: er.EntityRegistry,
) -> None:
    """Test removing a child device removes same-entry but orphans foreign entities.

    A child device is treated like a main device: an entity of the child's own
    config entry is removed, while an entity of a different config entry is detached
    (device_id set to None) rather than removed.
    """
    config_entry = MockConfigEntry(domain="test", title=None)
    config_entry.add_to_hass(hass)
    foreign_config_entry = MockConfigEntry(domain="some_helper")
    foreign_config_entry.add_to_hass(hass)

    parent = device_registry.async_get_or_create(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip")},
        name="Power strip",
    )
    child_device = device_registry.async_get_or_create_child(
        config_entry_id=config_entry.entry_id,
        identifiers={("test", "strip_outlet_1")},
        parent_device_id=parent.id,
        name="Outlet 1",
    )

    same_entry_entity = entity_registry.async_get_or_create(
        "switch",
        "test",
        "outlet_1",
        config_entry=config_entry,
        device_id=child_device.id,
    )
    foreign_entry_entity = entity_registry.async_get_or_create(
        "sensor",
        "some_helper",
        "outlet_1_power",
        config_entry=foreign_config_entry,
        device_id=child_device.id,
    )

    device_registry.async_remove_device(child_device.id)
    await hass.async_block_till_done()

    assert entity_registry.async_get(same_entry_entity.entity_id) is None
    foreign_entity = entity_registry.async_get(foreign_entry_entity.entity_id)
    assert foreign_entity is not None
    assert foreign_entity.device_id is None
