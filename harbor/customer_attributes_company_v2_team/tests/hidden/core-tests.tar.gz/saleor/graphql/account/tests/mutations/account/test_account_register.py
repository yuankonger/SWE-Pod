from unittest.mock import ANY, patch
from urllib.parse import urlencode

import pytest
from django.test import override_settings
from django.utils import timezone
from freezegun import freeze_time

from ......account import events as account_events
from ......account.models import User
from ......account.notifications import get_default_user_payload
from ......account.tasks import finish_creating_user
from ......core.notify import NotifyEventType
from ......core.tests.utils import get_site_context_payload
from ......core.tokens import account_confirm_token_generator
from ......core.utils.url import prepare_url
from ......settings import AUTH_PASSWORD_VALIDATORS
from ......tests import race_condition
from .....tests.utils import get_graphql_content

ACCOUNT_REGISTER_MUTATION = """
mutation RegisterAccount($input: AccountRegisterInput!) {
  accountRegister(input: $input) {
    errors {
      field
      message
      code
    }
    user {
      id
      email
      firstName
      lastName
      addresses {
        streetAddress1
      }
      metadata {
        key
      }
      metafield(key: "test")
      metafields(keys: ["test1"])
      checkout{
        id
      }
      checkoutTokens
      checkoutIds
      checkouts(first: 10) {
        edges {
          node {
            id
          }
        }
      }
      giftCards(first: 1) {
        edges {
          node {
            id
          }
        }
      }
      orders(first: 1) {
        edges {
          node {
            id
          }
        }
      }
      userPermissions {
        code
      }
      storedPaymentMethods(channel: "default-channel") {
        id
      }
      dateJoined
      lastLogin
      externalReference
      defaultBillingAddress {
        id
      }
      defaultShippingAddress {
        id
      }
      languageCode
      storedPaymentSources {
        __typename
      }
      avatar {
        url
      }
      isStaff
      isActive
      isConfirmed
      updatedAt
    }
  }
}
"""


@override_settings(
    ENABLE_ACCOUNT_CONFIRMATION_BY_EMAIL=True, ALLOWED_CLIENT_HOSTS=["localhost"]
)
@patch("saleor.account.notifications.account_confirm_token_generator.make_token")
@patch("saleor.plugins.manager.PluginsManager.notify")
@patch(
    "saleor.graphql.account.mutations.account.account_register.finish_creating_user",
    wraps=finish_creating_user,
)
def test_customer_register(
    mocked_finish_creating_user,
    mocked_notify,
    mocked_generator,
    api_client,
    channel_PLN,
    order,
    site_settings,
):
    # given
    mocked_generator.return_value = "token"
    email = "customer@example.com"

    redirect_url = "http://localhost:3000"
    variables = {
        "input": {
            "email": email,
            "password": "Password",
            "redirectUrl": redirect_url,
            "firstName": "saleor",
            "lastName": "rocks",
            "languageCode": "PL",
            "metadata": [{"key": "meta", "value": "data"}],
            "channel": channel_PLN.slug,
        }
    }
    query = ACCOUNT_REGISTER_MUTATION
    mutation_name = "accountRegister"

    # when
    response = api_client.post_graphql(query, variables)

    # then
    new_user = User.objects.get(email=email)
    content = get_graphql_content(response)
    data = content["data"][mutation_name]
    params = urlencode({"email": email, "token": "token"})
    confirm_url = prepare_url(params, redirect_url)

    expected_payload = {
        "user": get_default_user_payload(new_user),
        "token": "token",
        "confirm_url": confirm_url,
        "recipient_email": new_user.email,
        "channel_slug": channel_PLN.slug,
        **get_site_context_payload(site_settings.site),
    }
    assert data["user"]["firstName"] == variables["input"]["firstName"]
    assert data["user"]["lastName"] == variables["input"]["lastName"]
    assert data["user"]["email"] == variables["input"]["email"]
    assert data["user"]["id"] == ""
    assert new_user.metadata == {"meta": "data"}
    assert new_user.language_code == "pl"
    assert new_user.first_name == variables["input"]["firstName"]
    assert new_user.last_name == variables["input"]["lastName"]
    assert new_user.search_vector
    assert not data["errors"]
    assert mocked_notify.call_count == 1
    call_args = mocked_notify.call_args_list[0]
    called_args = call_args.args
    called_kwargs = call_args.kwargs
    assert called_args[0] == NotifyEventType.ACCOUNT_CONFIRMATION
    assert len(called_kwargs) == 2
    assert called_kwargs["payload_func"]() == expected_payload
    assert called_kwargs["channel_slug"] == channel_PLN.slug
    assert mocked_finish_creating_user.delay.called
    assert mocked_finish_creating_user.delay.call_args.args[0] == new_user.pk


@override_settings(
    ENABLE_ACCOUNT_CONFIRMATION_BY_EMAIL=True, ALLOWED_CLIENT_HOSTS=["localhost"]
)
@patch("saleor.account.notifications.account_confirm_token_generator.make_token")
@patch("saleor.plugins.manager.PluginsManager.notify")
@patch(
    "saleor.graphql.account.mutations.account.account_register.finish_creating_user",
    wraps=finish_creating_user,
)
def test_customer_register_twice(
    mocked_finish_creating_user,
    mocked_notify,
    mocked_generator,
    api_client,
    channel_PLN,
    order,
    site_settings,
):
    # given
    mocked_generator.return_value = "token"
    email = "customer@example.com"

    redirect_url = "http://localhost:3000"
    variables = {
        "input": {
            "email": email,
            "password": "Password",
            "redirectUrl": redirect_url,
            "firstName": "saleor",
            "lastName": "rocks",
            "languageCode": "PL",
            "metadata": [{"key": "meta", "value": "data"}],
            "channel": channel_PLN.slug,
        }
    }
    query = ACCOUNT_REGISTER_MUTATION
    mutation_name = "accountRegister"

    # when
    response = api_client.post_graphql(query, variables)

    # then
    new_user = User.objects.get(email=email)
    content = get_graphql_content(response)
    data = content["data"][mutation_name]
    params = urlencode({"email": email, "token": "token"})
    confirm_url = prepare_url(params, redirect_url)
    new_user.last_login = timezone.now()
    new_user.save()

    expected_payload = {
        "user": get_default_user_payload(new_user),
        "token": "token",
        "confirm_url": confirm_url,
        "recipient_email": new_user.email,
        "channel_slug": channel_PLN.slug,
        **get_site_context_payload(site_settings.site),
    }
    assert data["user"]["firstName"] == variables["input"]["firstName"]
    assert data["user"]["lastName"] == variables["input"]["lastName"]
    assert data["user"]["email"] == variables["input"]["email"]
    assert data["user"]["id"] == ""
    assert new_user.metadata == {"meta": "data"}
    assert new_user.language_code == "pl"
    assert new_user.first_name == variables["input"]["firstName"]
    assert new_user.last_name == variables["input"]["lastName"]
    assert new_user.search_vector
    assert not data["errors"]
    assert mocked_notify.call_count == 1
    call_args = mocked_notify.call_args_list[0]
    called_args = call_args.args
    called_kwargs = call_args.kwargs
    assert called_args[0] == NotifyEventType.ACCOUNT_CONFIRMATION
    assert len(called_kwargs) == 2
    assert called_kwargs["payload_func"]() == expected_payload
    assert called_kwargs["channel_slug"] == channel_PLN.slug
    assert mocked_finish_creating_user.delay.called
    assert mocked_finish_creating_user.delay.call_args.args[0] == new_user.pk

    # when
    # remove personal data from input
    del variables["input"]["firstName"]
    del variables["input"]["lastName"]
    with freeze_time("2025-06-01 12:00:01"):
        query_time = timezone.now()
        response = api_client.post_graphql(query, variables)
        content = get_graphql_content(response)
        data = content["data"][mutation_name]

    # then
    assert not data["errors"]

    new_user.refresh_from_db()
    assert new_user.updated_at != query_time
    assert new_user.date_joined != query_time
    assert new_user.last_login is not None

    customer_creation_event = account_events.CustomerEvent.objects.get()
    assert data["user"]["firstName"] == ""
    assert data["user"]["lastName"] == ""
    assert data["user"]["email"] == variables["input"]["email"]
    assert data["user"]["id"] == ""
    assert data["user"]["updatedAt"] == query_time.isoformat()
    assert data["user"]["dateJoined"] == query_time.isoformat()
    assert data["user"]["lastLogin"] is None
    assert customer_creation_event.type == account_events.CustomerEvents.ACCOUNT_CREATED
    assert customer_creation_event.user == new_user
    assert mocked_finish_creating_user.delay.call_count == 2
    assert mocked_finish_creating_user.delay.call_args.args[0] is None


@override_settings(
    ENABLE_ACCOUNT_CONFIRMATION_BY_EMAIL=True, ALLOWED_CLIENT_HOSTS=["localhost"]
)
@patch("saleor.plugins.manager.PluginsManager.notify")
def test_customer_register_generates_valid_token(
    mocked_notify,
    api_client,
    channel_PLN,
    order,
    site_settings,
):
    # given
    email = "customer@example.com"
    redirect_url = "http://localhost:3000"
    variables = {
        "input": {
            "email": email,
            "password": "Password",
            "redirectUrl": redirect_url,
            "firstName": "saleor",
            "lastName": "rocks",
            "languageCode": "PL",
            "metadata": [{"key": "meta", "value": "data"}],
            "channel": channel_PLN.slug,
        }
    }

    # when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)
    new_user = User.objects.get(email=email)
    content = get_graphql_content(response)
    data = content["data"]["accountRegister"]

    # then
    assert mocked_notify.call_count == 1
    call_args = mocked_notify.call_args_list[0]
    called_kwargs = call_args.kwargs
    token = called_kwargs["payload_func"]()["token"]
    assert called_kwargs["channel_slug"] == channel_PLN.slug

    assert not data["errors"]
    assert account_confirm_token_generator.check_token(new_user, token)


@patch("saleor.plugins.manager.PluginsManager.notify")
def test_customer_register_disabled_email_confirmation(
    mocked_notify, api_client, site_settings
):
    # given
    site_settings.enable_account_confirmation_by_email = False
    site_settings.save(update_fields=["enable_account_confirmation_by_email"])

    email = "customer@example.com"
    variables = {"input": {"email": email, "password": "Password"}}

    #   when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)
    errors = response.json()["data"]["accountRegister"]["errors"]

    # then
    assert errors == []
    created_user = User.objects.get()
    expected_payload = get_default_user_payload(created_user)
    expected_payload["token"] = "token"
    expected_payload["redirect_url"] = "http://localhost:3000"
    mocked_notify.assert_not_called()


@patch("saleor.plugins.manager.PluginsManager.notify")
def test_customer_register_no_redirect_url(mocked_notify, api_client, site_settings):
    # given
    site_settings.enable_account_confirmation_by_email = True
    site_settings.save(update_fields=["enable_account_confirmation_by_email"])

    variables = {"input": {"email": "customer@example.com", "password": "Password"}}

    #   when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)
    errors = response.json()["data"]["accountRegister"]["errors"]

    # then
    assert "redirectUrl" in (error["field"] for error in errors)
    mocked_notify.assert_not_called()


@override_settings(ENABLE_ACCOUNT_CONFIRMATION_BY_EMAIL=False)
def test_customer_register_upper_case_email(api_client, site_settings):
    # given
    site_settings.enable_account_confirmation_by_email = False
    site_settings.save(update_fields=["enable_account_confirmation_by_email"])

    email = "CUSTOMER@example.com"
    variables = {"input": {"email": email, "password": "Password"}}

    # when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)
    content = get_graphql_content(response)

    # then
    data = content["data"]["accountRegister"]
    assert not data["errors"]
    assert data["user"]["email"].lower()


@patch("saleor.plugins.manager.PluginsManager.notify")
def test_customer_register_no_channel_email_confirmation_unset(
    mocked_notify, api_client, channel_PLN, site_settings
):
    # given
    site_settings.enable_account_confirmation_by_email = False
    site_settings.save(update_fields=["enable_account_confirmation_by_email"])

    email = "customer@example.com"
    redirect_url = "http://localhost:3000"
    variables = {
        "input": {
            "email": email,
            "password": "Password",
            "redirectUrl": redirect_url,
            "firstName": "saleor",
            "lastName": "rocks",
            "languageCode": "PL",
            "metadata": [{"key": "meta", "value": "data"}],
        }
    }

    # when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)
    content = get_graphql_content(response)
    data = content["data"]["accountRegister"]

    # then
    data = content["data"]["accountRegister"]
    assert not data["errors"]
    assert data["user"]["email"].lower()
    mocked_notify.assert_not_called()


def test_account_register_properly_filter_errors(
    api_client, channel_PLN, site_settings
):
    # given
    site_settings.enable_account_confirmation_by_email = False
    site_settings.save(update_fields=["enable_account_confirmation_by_email"])

    email = "customer"
    variables = {
        "input": {
            "email": email,
            "password": "Password",
            "firstName": "saleor",
            "lastName": "rocks",
        }
    }

    # when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)
    content = get_graphql_content(response)

    # then
    errors = content["data"]["accountRegister"]["errors"]
    assert errors
    assert errors[0]["code"] == "INVALID"
    assert errors[0]["field"] == "email"


def test_account_register_returns_empty_id(
    api_client, channel_PLN, site_settings, customer_user
):
    # given
    site_settings.enable_account_confirmation_by_email = False
    site_settings.save(update_fields=["enable_account_confirmation_by_email"])

    variables = {
        "input": {
            "email": customer_user.email,
            "password": "Password",
        }
    }

    # when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)
    content = get_graphql_content(response)

    # then
    data = content["data"]["accountRegister"]
    assert not data["errors"]
    assert data["user"]["id"] == ""
    assert data["user"]["email"] == customer_user.email


@override_settings(
    ENABLE_ACCOUNT_CONFIRMATION_BY_EMAIL=True, ALLOWED_CLIENT_HOSTS=["localhost"]
)
@patch("saleor.account.notifications.account_confirm_token_generator.make_token")
@patch("saleor.plugins.manager.PluginsManager.notify")
@patch(
    "saleor.graphql.account.mutations.account.account_register.finish_creating_user",
    wraps=finish_creating_user,
)
def test_customer_register_race_codition(
    mocked_finish_creating_user,
    mocked_notify,
    mocked_generator,
    api_client,
    channel_PLN,
):
    # given
    mocked_generator.return_value = "token"
    email = "customer@example.com"

    redirect_url = "http://localhost:3000"
    variables = {
        "input": {
            "email": email,
            "password": "Password",
            "redirectUrl": redirect_url,
            "firstName": "saleor",
            "lastName": "rocks",
            "languageCode": "PL",
            "channel": channel_PLN.slug,
        }
    }

    def create_new_user(*args, **kwargs):
        User.objects.create(email=email)

    # when
    with race_condition.RunBefore(
        "saleor.graphql.account.mutations.account.account_register."
        "AccountRegister.save_and_create_task",
        create_new_user,
    ):
        response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)

    # then
    content = get_graphql_content(response)
    data = content["data"]["accountRegister"]

    assert data["user"]["firstName"] == variables["input"]["firstName"]
    assert data["user"]["lastName"] == variables["input"]["lastName"]
    assert data["user"]["email"] == variables["input"]["email"]
    assert data["user"]["id"] == ""
    assert not data["errors"]

    assert not mocked_notify.called
    mocked_finish_creating_user.delay.assert_called_once_with(
        None, redirect_url, channel_PLN.slug, ANY
    )


@pytest.mark.parametrize(("enable_account_confirmation_by_email"), [True, False])
def test_validates_password_length(
    api_client,
    site_settings,
    enable_account_confirmation_by_email: bool,
    channel_PLN,
    settings,
):
    """Should validate password length even when account confirmation is disabled."""

    settings.ALLOWED_CLIENT_HOSTS = ["localhost"]
    settings.AUTH_PASSWORD_VALIDATORS = AUTH_PASSWORD_VALIDATORS  # production values

    site_settings.enable_account_confirmation_by_email = (
        enable_account_confirmation_by_email
    )
    site_settings.save(update_fields=["enable_account_confirmation_by_email"])

    variables = {
        "input": {
            "email": "foo@example.com",
            "password": "a",
            "redirectUrl": "http://localhost:3000",
            "firstName": "saleor",
            "lastName": "rocks",
            "languageCode": "PL",
            "channel": channel_PLN.slug,
        }
    }

    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)

    # then
    content = get_graphql_content(response)
    data = content["data"]["accountRegister"]
    assert data == {
        "errors": [
            {
                "code": "PASSWORD_TOO_SHORT",
                "field": "password",
                "message": (
                    "This password is too short. It must contain at least 8 characters."
                ),
            },
        ],
        "user": None,
    }


@override_settings(ALLOWED_CLIENT_HOSTS=["localhost"])
def test_register_assigns_default_customer_type(
    api_client, channel_PLN, default_customer_type
):
    # given
    email = "customer-type@example.com"
    variables = {
        "input": {
            "email": email,
            "password": "Password",
            "redirectUrl": "http://localhost:3000",
            "channel": channel_PLN.slug,
        }
    }

    # when
    response = api_client.post_graphql(ACCOUNT_REGISTER_MUTATION, variables)

    # then
    content = get_graphql_content(response)
    assert not content["data"]["accountRegister"]["errors"]
    new_user = User.objects.get(email=email)
    assert new_user.customer_type == default_customer_type
