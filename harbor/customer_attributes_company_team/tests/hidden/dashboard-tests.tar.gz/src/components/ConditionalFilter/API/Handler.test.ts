import { type ApolloClient, type ApolloQueryResult } from "@apollo/client";
import {
  _GetWarehouseChoicesDocument,
  type _GetWarehouseChoicesQuery,
  type _GetWarehouseChoicesQueryVariables,
} from "@dashboard/graphql";

import { FILTER_CHOICES_PAGE_SIZE } from "./filterChoicesPage";
import { WarehouseHandler } from "./Handler";

describe("WarehouseHandler", () => {
  let mockClient: jest.Mocked<ApolloClient<unknown>>;

  beforeEach(() => {
    mockClient = {
      query: jest.fn(),
    } as unknown as jest.Mocked<ApolloClient<unknown>>;
  });

  it("fetches warehouses with correct query and variables", async () => {
    // Arrange
    const searchQuery = "main";
    const handler = new WarehouseHandler(mockClient, searchQuery);

    const mockResponse: _GetWarehouseChoicesQuery = {
      __typename: "Query" as const,
      warehouses: {
        __typename: "WarehouseCountableConnection",
        pageInfo: {
          __typename: "PageInfo",
          hasNextPage: false,
          endCursor: null,
        },
        edges: [
          {
            __typename: "WarehouseCountableEdge",
            node: {
              __typename: "Warehouse",
              id: "WRH123",
              name: "Main Warehouse",
              slug: "main-warehouse",
            },
          },
          {
            __typename: "WarehouseCountableEdge",
            node: {
              __typename: "Warehouse",
              id: "WRH456",
              name: "Main Distribution Center",
              slug: "main-distribution",
            },
          },
        ],
      },
    };

    mockClient.query.mockResolvedValueOnce({
      data: mockResponse,
    } as ApolloQueryResult<_GetWarehouseChoicesQuery>);

    // Act
    const result = await handler.fetch();

    // Assert
    expect(mockClient.query).toHaveBeenCalledWith({
      query: _GetWarehouseChoicesDocument,
      variables: {
        first: FILTER_CHOICES_PAGE_SIZE,
        after: undefined,
        query: searchQuery,
      } as _GetWarehouseChoicesQueryVariables,
    });

    expect(result).toEqual([
      {
        label: "Main Warehouse",
        value: "WRH123",
        slug: "main-warehouse",
        originalSlug: undefined,
      },
      {
        label: "Main Distribution Center",
        value: "WRH456",
        slug: "main-distribution",
        originalSlug: undefined,
      },
    ]);
    expect(handler.pageInfo).toEqual({ hasNextPage: false, endCursor: null });
  });

  it("requests the next page when after is provided", async () => {
    // Arrange
    const handler = new WarehouseHandler(mockClient, "main");
    const mockResponse: _GetWarehouseChoicesQuery = {
      __typename: "Query" as const,
      warehouses: {
        __typename: "WarehouseCountableConnection",
        pageInfo: {
          __typename: "PageInfo",
          hasNextPage: true,
          endCursor: "cursor-2",
        },
        edges: [
          {
            __typename: "WarehouseCountableEdge",
            node: {
              __typename: "Warehouse",
              id: "WRH789",
              name: "Overflow Warehouse",
              slug: "overflow",
            },
          },
        ],
      },
    };

    mockClient.query.mockResolvedValueOnce({
      data: mockResponse,
    } as ApolloQueryResult<_GetWarehouseChoicesQuery>);

    // Act
    const result = await handler.fetch("cursor-1");

    // Assert
    expect(mockClient.query).toHaveBeenCalledWith({
      query: _GetWarehouseChoicesDocument,
      variables: {
        first: FILTER_CHOICES_PAGE_SIZE,
        after: "cursor-1",
        query: "main",
      } as _GetWarehouseChoicesQueryVariables,
    });
    expect(result).toHaveLength(1);
    expect(handler.pageInfo).toEqual({ hasNextPage: true, endCursor: "cursor-2" });
  });

  it("handles empty search query", async () => {
    // Arrange
    const handler = new WarehouseHandler(mockClient, "");

    const mockResponse: _GetWarehouseChoicesQuery = {
      __typename: "Query" as const,
      warehouses: {
        __typename: "WarehouseCountableConnection",
        pageInfo: {
          __typename: "PageInfo",
          hasNextPage: false,
          endCursor: null,
        },
        edges: [
          {
            __typename: "WarehouseCountableEdge",
            node: {
              __typename: "Warehouse",
              id: "WRH1",
              name: "Warehouse 1",
              slug: "warehouse-1",
            },
          },
        ],
      },
    };

    mockClient.query.mockResolvedValueOnce({
      data: mockResponse,
    } as ApolloQueryResult<_GetWarehouseChoicesQuery>);

    // Act
    const result = await handler.fetch();

    // Assert
    expect(mockClient.query).toHaveBeenCalledWith({
      query: _GetWarehouseChoicesDocument,
      variables: {
        first: FILTER_CHOICES_PAGE_SIZE,
        after: undefined,
        query: "",
      },
    });

    expect(result).toEqual([
      {
        label: "Warehouse 1",
        value: "WRH1",
        slug: "warehouse-1",
        originalSlug: undefined,
      },
    ]);
  });

  it("handles empty response with no warehouses", async () => {
    // Arrange
    const handler = new WarehouseHandler(mockClient, "nonexistent");

    const mockResponse: _GetWarehouseChoicesQuery = {
      __typename: "Query" as const,
      warehouses: {
        __typename: "WarehouseCountableConnection",
        pageInfo: {
          __typename: "PageInfo",
          hasNextPage: false,
          endCursor: null,
        },
        edges: [],
      },
    };

    mockClient.query.mockResolvedValueOnce({
      data: mockResponse,
    } as ApolloQueryResult<_GetWarehouseChoicesQuery>);

    // Act
    const result = await handler.fetch();

    // Assert
    expect(result).toEqual([]);
  });

  it("handles null warehouses response", async () => {
    // Arrange
    const handler = new WarehouseHandler(mockClient as unknown as ApolloClient<unknown>, "test");

    const mockResponse: _GetWarehouseChoicesQuery = {
      __typename: "Query" as const,
      warehouses: null,
    };

    mockClient.query.mockResolvedValueOnce({
      data: mockResponse,
    } as ApolloQueryResult<_GetWarehouseChoicesQuery>);

    // Act
    const result = await handler.fetch();

    // Assert
    expect(result).toEqual([]);
  });

  it("propagates apollo client query errors", async () => {
    // Arrange
    const handler = new WarehouseHandler(mockClient as unknown as ApolloClient<unknown>, "test");
    const error = new Error("Network error");

    mockClient.query.mockRejectedValueOnce(error);

    // Act & Assert
    await expect(handler.fetch()).rejects.toThrow("Network error");
  });
});
